import json
import os
from datetime import datetime
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request
from google import genai
from google.genai import types

load_dotenv()

app = Flask(__name__)


def sanitize_text(value, max_len: int = 500) -> str:
    if not isinstance(value, str):
        return ""
    return value.strip()[:max_len]


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    return jsonify({"ok": True, "runtime": "python-flask", "timestamp": datetime.utcnow().isoformat()})


@app.route("/api/ai/study-coach", methods=["POST"])
def ai_study_coach():
    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        return (
            jsonify(
                {
                    "error": "Chưa cấu hình GEMINI_API_KEY trong biến môi trường hoặc tệp .env."
                }
            ),
            500,
        )

    payload = request.get_json(silent=True) or {}
    notes_raw = payload.get("notes")
    schedule_raw = payload.get("dailySchedule")
    goals_raw = payload.get("weeklyGoals")

    if not isinstance(notes_raw, list) or not isinstance(schedule_raw, list) or not isinstance(goals_raw, list):
        return (
            jsonify(
                {
                    "error": "Dữ liệu đầu vào không hợp lệ. Cần danh sách ghi chú, lịch trình và mục tiêu tuần."
                }
            ),
            400,
        )

    notes = [
        {
            "id": sanitize_text(n.get("id"), 64),
            "title": sanitize_text(n.get("title"), 160),
            "content": sanitize_text(n.get("content"), 600),
            "category": sanitize_text(n.get("category"), 40),
            "priority": sanitize_text(n.get("priority"), 20),
            "scheduledDate": sanitize_text(n.get("scheduledDate"), 20),
            "scheduledTime": sanitize_text(n.get("scheduledTime"), 10),
            "durationMinutes": max(15, min(360, int(n.get("durationMinutes", 60) or 60))),
            "completed": bool(n.get("completed", False)),
        }
        for n in notes_raw[:60]
        if isinstance(n, dict)
    ]

    daily_schedule = [
        {
            "id": sanitize_text(b.get("id"), 64),
            "startTime": sanitize_text(b.get("startTime"), 10),
            "endTime": sanitize_text(b.get("endTime"), 10),
            "label": sanitize_text(b.get("label"), 120),
            "status": sanitize_text(b.get("status"), 30),
        }
        for b in schedule_raw[:30]
        if isinstance(b, dict)
    ]

    weekly_goals = [
        {
            "id": sanitize_text(g.get("id"), 64),
            "title": sanitize_text(g.get("title"), 140),
            "category": sanitize_text(g.get("category"), 40),
            "targetCount": max(1, min(500, int(g.get("targetCount", 1) or 1))),
            "completedCount": max(0, min(500, int(g.get("completedCount", 0) or 0))),
            "unit": sanitize_text(g.get("unit"), 20),
        }
        for g in goals_raw[:20]
        if isinstance(g, dict)
    ]

    custom_prompt = sanitize_text(payload.get("customPrompt"), 400)
    current_date = sanitize_text(payload.get("currentDate"), 20) or datetime.now().strftime("%Y-%m-%d")

    system_instruction = (
        "Bạn là Trợ lý AI Quản lý Học tập cá nhân thông minh, súc tích và thực tế.\n"
        "1. Đọc kỹ toàn bộ nội dung các ghi chú (phát hiện các khoảng thời gian trống người dùng ghi trong nội dung như '19:30 - 21:30', 'rảnh 14h-16h') kết hợp Lịch trình hàng ngày.\n"
        "2. Đề xuất ĐÚNG 3 khung giờ học tập hiệu quả nhất trong ngày.\n"
        "3. Đánh giá tiến độ mục tiêu tuần bằng tiếng Việt tự nhiên."
    )

    prompt_text = f"""
Ngày hiện tại: {current_date}
Yêu cầu bổ sung: {custom_prompt or "Không có"}

=== LỊCH TRÌNH HÀNG NGÀY ===
{json.dumps(daily_schedule, ensure_ascii=False, indent=2)}

=== DANH SÁCH GHI CHÚ ===
{json.dumps(notes, ensure_ascii=False, indent=2)}

=== MỤC TIÊU HÀNG TUẦN ===
{json.dumps(weekly_goals, ensure_ascii=False, indent=2)}
""".strip()

    try:
        client = genai.Client(api_key=api_key)
        response_schema = types.Schema(
            type=types.Type.OBJECT,
            properties={
                "overallAssessment": types.Schema(type=types.Type.STRING),
                "extractedFreeWindows": types.Schema(
                    type=types.Type.ARRAY,
                    items=types.Schema(type=types.Type.STRING),
                ),
                "suggestedSlots": types.Schema(
                    type=types.Type.ARRAY,
                    items=types.Schema(
                        type=types.Type.OBJECT,
                        properties={
                            "slotOrder": types.Schema(type=types.Type.INTEGER),
                            "dayLabel": types.Schema(type=types.Type.STRING),
                            "recommendedDate": types.Schema(type=types.Type.STRING),
                            "startTime": types.Schema(type=types.Type.STRING),
                            "timeRange": types.Schema(type=types.Type.STRING),
                            "durationMinutes": types.Schema(type=types.Type.INTEGER),
                            "focusTopic": types.Schema(type=types.Type.STRING),
                            "linkedNoteTitle": types.Schema(type=types.Type.STRING),
                            "reason": types.Schema(type=types.Type.STRING),
                        },
                    ),
                ),
                "weeklyGoalAnalysis": types.Schema(
                    type=types.Type.ARRAY,
                    items=types.Schema(
                        type=types.Type.OBJECT,
                        properties={
                            "goalTitle": types.Schema(type=types.Type.STRING),
                            "completionPercent": types.Schema(type=types.Type.INTEGER),
                            "status": types.Schema(type=types.Type.STRING),
                            "actionableTip": types.Schema(type=types.Type.STRING),
                        },
                    ),
                ),
                "scheduleTip": types.Schema(type=types.Type.STRING),
            },
        )

        response = client.models.generate_content(
            model="gemini-4-hydrogen",
            contents=prompt_text,
            config=types.GenerateContentConfig(
                system_instruction=system_instruction,
                response_mime_type="application/json",
                response_schema=response_schema,
            ),
        )

        if not response.text:
            return jsonify({"error": "Gemini AI không trả về dữ liệu."}), 502

        return jsonify(json.loads(response.text))
    except Exception as exc:
        return jsonify({"error": f"Lỗi khi gọi Gemini AI: {exc}"}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=True)
