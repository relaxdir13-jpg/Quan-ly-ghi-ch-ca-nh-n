const STORAGE_KEYS = {
  NOTES: "py_study_notes_v1",
  SCHEDULE: "py_study_schedule_v1",
  GOALS: "py_study_goals_v1",
};

const SEED_GOALS = [
  { id: "goal-py", title: "Hoàn thành học phần Python Web (Flask & FastAPI)", category: "Học tập", targetCount: 5, completedCount: 3, unit: "buổi" },
  { id: "goal-sql", title: "Thực hành thiết kế CSDL & tối ưu truy vấn SQL", category: "Dự án", targetCount: 4, completedCount: 2, unit: "bài tập" },
  { id: "goal-algo", title: "Giải bài tập Cấu trúc dữ liệu & Thuật toán", category: "Ôn tập", targetCount: 6, completedCount: 4, unit: "bài" },
  { id: "goal-en", title: "Đọc tài liệu kỹ thuật tiếng Anh & rèn thói quen", category: "Cá nhân", targetCount: 180, completedCount: 120, unit: "phút" },
];

const SEED_SCHEDULE = [
  { id: "blk-1", startTime: "06:30", endTime: "07:45", label: "Đọc tài liệu buổi sáng", status: "Rảnh - Có thể học" },
  { id: "blk-2", startTime: "08:00", endTime: "11:30", label: "Học trên lớp / Làm việc", status: "Bận" },
  { id: "blk-3", startTime: "11:45", endTime: "13:30", label: "Ăn trưa & nghỉ ngơi", status: "Nghỉ ngơi" },
  { id: "blk-4", startTime: "14:00", endTime: "16:30", label: "Tự học thực hành buổi chiều", status: "Rảnh - Có thể học" },
  { id: "blk-5", startTime: "17:00", endTime: "19:00", label: "Thể thao & ăn tối", status: "Nghỉ ngơi" },
  { id: "blk-6", startTime: "19:30", endTime: "21:30", label: "Tập trung sâu buổi tối", status: "Rảnh - Có thể học" },
];

const SEED_NOTES = [
  { id: "n1", title: "Ôn tập Routing & Jinja2 trong Python Flask", content: "Hệ thống lại URL động và base.html. Khung giờ trống: 06:30 - 07:45 sáng.", category: "Học tập", priority: "Cao", scheduledDate: "2026-11-23", scheduledTime: "06:30", durationMinutes: 75, completed: true, reminderEnabled: true, orderIndex: 0, goalId: "goal-py" },
  { id: "n2", title: "Thiết kế lược đồ CSDL Quản lý Ghi chú với SQLAlchemy", content: "Xây dựng bảng notes và study_schedules có khóa ngoại rõ ràng.", category: "Dự án", priority: "Cao", scheduledDate: "2026-11-23", scheduledTime: "19:30", durationMinutes: 90, completed: true, reminderEnabled: true, orderIndex: 1, goalId: "goal-sql" },
  { id: "n3", title: "Luyện 3 bài Quy hoạch động cơ bản", content: "Giải Knapsack 0/1, LIS và đường đi ngắn nhất trên lưới.", category: "Ôn tập", priority: "Trung bình", scheduledDate: "2026-11-24", scheduledTime: "14:30", durationMinutes: 60, completed: true, reminderEnabled: true, orderIndex: 2, goalId: "goal-algo" },
  { id: "n4", title: "Đọc tài liệu FastAPI Async & Dependency Injection", content: "Ghi chú dùng Depends(). Hôm nay rảnh 20:00 - 21:30 buổi tối để thử code mẫu.", category: "Học tập", priority: "Cao", scheduledDate: "2026-11-24", scheduledTime: "20:00", durationMinutes: 90, completed: true, reminderEnabled: true, orderIndex: 3, goalId: "goal-py" },
  { id: "n5", title: "Lịch nhắc: Hoàn thiện CRUD & lưu trữ LocalStorage", content: "Kiểm thử thêm, xóa, sửa, sắp xếp. Trống từ 14:15 - 16:00 chiều nay.", category: "Lịch nhắc", priority: "Cao", scheduledDate: "2026-11-25", scheduledTime: "14:15", durationMinutes: 90, completed: false, reminderEnabled: true, orderIndex: 4, goalId: "goal-py" },
  { id: "n6", title: "Đọc 2 bài viết tiếng Anh về REST API Caching", content: "Tổng hợp từ vựng ETag, Cache-Control. Rảnh buổi tối 19:30 - 20:45.", category: "Cá nhân", priority: "Trung bình", scheduledDate: "2026-11-25", scheduledTime: "19:30", durationMinutes: 60, completed: false, reminderEnabled: true, orderIndex: 5, goalId: "goal-en" },
  { id: "n7", title: "Lịch nhắc: Kiểm tra 5 câu truy vấn JOIN & GROUP BY", content: "Tối ưu thống kê bằng CTE. Thời gian trống buổi sáng: 06:30 - 07:45.", category: "Lịch nhắc", priority: "Cao", scheduledDate: "2026-11-26", scheduledTime: "06:30", durationMinutes: 60, completed: false, reminderEnabled: true, orderIndex: 6, goalId: "goal-sql" },
  { id: "n8", title: "Viết Unit Test bằng Pytest cho endpoint ghi chú", content: "Tạo fixture giả lập 10 ghi chú. Rảnh 14:30 - 16:30 chiều thứ Năm.", category: "Dự án", priority: "Trung bình", scheduledDate: "2026-11-26", scheduledTime: "14:30", durationMinutes: 90, completed: false, reminderEnabled: true, orderIndex: 7, goalId: "goal-py" },
  { id: "n9", title: "Ôn tập Cây nhị phân tìm kiếm & BFS/DFS", content: "Cài đặt lại bằng Python thuần để hiểu rõ độ phức tạp O(V + E).", category: "Ôn tập", priority: "Cao", scheduledDate: "2026-11-27", scheduledTime: "19:45", durationMinutes: 75, completed: false, reminderEnabled: true, orderIndex: 8, goalId: "goal-algo" },
  { id: "n10", title: "Lịch nhắc: Đóng gói báo cáo tiến độ tuần & dọn Git branch", content: "Viết README mô tả cách chạy Python Flask và chuẩn hóa commit.", category: "Lịch nhắc", priority: "Thấp", scheduledDate: "2026-11-28", scheduledTime: "15:00", durationMinutes: 45, completed: false, reminderEnabled: true, orderIndex: 9, goalId: "goal-sql" },
  { id: "n11", title: "Đọc sách Clean Code (Chương Hàm & Đặt tên)", content: "Ghi 5 nguyên tắc tách hàm nhỏ gọn trong Python.", category: "Cá nhân", priority: "Thấp", scheduledDate: "2026-11-28", scheduledTime: "21:00", durationMinutes: 45, completed: false, reminderEnabled: false, orderIndex: 10, goalId: "goal-en" },
  { id: "n12", title: "Tổng kết tuần & Lập mục tiêu tuần kế tiếp", content: "Rà soát tỷ lệ hoàn thành 4 mục tiêu tuần và đặt lịch nhắc mới.", category: "Lịch nhắc", priority: "Trung bình", scheduledDate: "2026-11-29", scheduledTime: "20:00", durationMinutes: 60, completed: false, reminderEnabled: true, orderIndex: 11, goalId: "goal-py" },
];

function loadStore(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) {
      localStorage.setItem(key, JSON.stringify(fallback));
      return structuredClone(fallback);
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) && parsed.length ? parsed : structuredClone(fallback);
  } catch {
    return structuredClone(fallback);
  }
}

function saveStore(key, data) {
  localStorage.setItem(key, JSON.stringify(data));
}

let state = {
  view: "notes",
  notes: loadStore(STORAGE_KEYS.NOTES, SEED_NOTES),
  schedule: loadStore(STORAGE_KEYS.SCHEDULE, SEED_SCHEDULE),
  goals: loadStore(STORAGE_KEYS.GOALS, SEED_GOALS),
  search: "",
  category: "Tất cả",
  sort: "custom",
  viewMode: "list",
  aiResult: null,
};

function showToast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.remove("hidden");
  clearTimeout(showToast._t);
  showToast._t = setTimeout(() => el.classList.add("hidden"), 2800);
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function extractFreeWindowsFromNotes(notes) {
  const regex = /(?:từ\s*)?(\d{1,2})\s*[:h]\s*(\d{0,2})\s*(?:-|–|đến|to)\s*(\d{1,2})\s*[:h]\s*(\d{0,2})/gi;
  const found = [];
  for (const n of notes) {
    const text = `${n.title} ${n.content}`;
    let m;
    regex.lastIndex = 0;
    while ((m = regex.exec(text)) !== null) {
      const sh = Number(m[1]), sm = Number(m[2] || 0);
      const eh = Number(m[3]), em = Number(m[4] || 0);
      if (sh > 23 || eh > 23 || sm > 59 || em > 59) continue;
      const startMin = sh * 60 + sm;
      const endMin = eh * 60 + em;
      const dur = endMin - startMin;
      if (dur < 25 || dur > 360) continue;
      const pad = (x) => String(x).padStart(2, "0");
      found.push({
        noteId: n.id,
        noteTitle: n.title,
        startTime: `${pad(sh)}:${pad(sm)}`,
        endTime: `${pad(eh)}:${pad(em)}`,
        durationMinutes: dur,
        period: startMin < 720 ? "Buổi sáng" : startMin < 1080 ? "Buổi chiều" : "Buổi tối",
      });
    }
  }
  return found;
}

function suggestThreeStudySlotsJS(notes, schedule) {
  const extracted = extractFreeWindowsFromNotes(notes);
  const pending = notes.filter((n) => !n.completed).sort((a, b) => {
    const w = { Cao: 3, "Trung bình": 2, Thấp: 1 };
    return (w[b.priority] || 1) - (w[a.priority] || 1);
  });

  const candidates = extracted.map((e) => ({
    ...e,
    source: `Trích từ ghi chú "${e.noteTitle}"`,
    weight: 2,
  }));

  for (const blk of schedule) {
    if (blk.status !== "Rảnh - Có thể học") continue;
    const [sh, sm] = blk.startTime.split(":").map(Number);
    const [eh, em] = blk.endTime.split(":").map(Number);
    const dur = eh * 60 + em - (sh * 60 + sm);
    if (dur >= 30) {
      candidates.push({
        startTime: blk.startTime,
        endTime: blk.endTime,
        durationMinutes: dur,
        period: sh * 60 < 720 ? "Buổi sáng" : sh * 60 < 1080 ? "Buổi chiều" : "Buổi tối",
        source: `Lịch trình: ${blk.label}`,
        weight: 1,
      });
    }
  }

  const picked = [];
  const usedPeriods = new Set();
  for (const c of candidates.sort((a, b) => b.weight - a.weight || b.durationMinutes - a.durationMinutes)) {
    if (picked.length >= 3) break;
    if (!usedPeriods.has(c.period)) {
      picked.push(c);
      usedPeriods.add(c.period);
    }
  }
  for (const c of candidates) {
    if (picked.length >= 3) break;
    if (!picked.includes(c)) picked.push(c);
  }

  return {
    extracted,
    slots: picked.slice(0, 3).map((s, idx) => {
      const task = pending[idx];
      return {
        order: idx + 1,
        timeRange: `${s.startTime} – ${s.endTime}`,
        startTime: s.startTime,
        durationMinutes: s.durationMinutes,
        period: s.period,
        source: s.source,
        taskTitle: task ? task.title : "Ôn tập trọng tâm & rà soát ghi chú",
      };
    }),
  };
}

function updateSidebarSummary() {
  const doneNotes = state.notes.filter((n) => n.completed).length;
  const dates = new Set(state.notes.map((n) => n.scheduledDate).filter(Boolean));
  const avgGoalPct = state.goals.length
    ? Math.round(
        state.goals.reduce((acc, g) => acc + Math.min(100, Math.round((g.completedCount / Math.max(1, g.targetCount)) * 100)), 0) /
          state.goals.length
      )
    : 0;

  document.getElementById("sidebar-goal-pct").textContent = `${avgGoalPct}%`;
  document.getElementById("sidebar-goal-bar").style.width = `${avgGoalPct}%`;
  document.getElementById("sidebar-notes-done").textContent = `${doneNotes}/${state.notes.length}`;
  document.getElementById("sidebar-span-days").textContent = `${dates.size} ngày`;
}

function getFilteredNotes() {
  const q = state.search.trim().toLowerCase();
  const list = state.notes.filter((n) => {
    if (state.category !== "Tất cả" && n.category !== state.category) return false;
    if (q && !n.title.toLowerCase().includes(q) && !n.content.toLowerCase().includes(q)) return false;
    return true;
  });

  const w = { Cao: 3, "Trung bình": 2, Thấp: 1 };
  if (state.sort === "custom") list.sort((a, b) => a.orderIndex - b.orderIndex);
  if (state.sort === "schedule_asc") list.sort((a, b) => `${a.scheduledDate} ${a.scheduledTime}`.localeCompare(`${b.scheduledDate} ${b.scheduledTime}`));
  if (state.sort === "priority_desc") list.sort((a, b) => (w[b.priority] || 1) - (w[a.priority] || 1));
  if (state.sort === "title_asc") list.sort((a, b) => a.title.localeCompare(b.title, "vi"));
  return list;
}

function renderNotesView(root) {
  const filtered = getFilteredNotes();
  const doneCount = state.notes.filter((n) => n.completed).length;
  const remCount = state.notes.filter((n) => !n.completed && n.reminderEnabled).length;
  const daysCount = new Set(state.notes.map((n) => n.scheduledDate)).size;

  root.innerHTML = `
    <div class="kpi-grid">
      <div class="kpi-cell"><div class="kpi-label">Tổng số ghi chú</div><div class="kpi-value mono">${state.notes.length}</div></div>
      <div class="kpi-cell"><div class="kpi-label">Đã hoàn thành</div><div class="kpi-value mono">${doneCount}/${state.notes.length}</div></div>
      <div class="kpi-cell"><div class="kpi-label">Lịch nhắc chờ</div><div class="kpi-value mono">${remCount}</div></div>
      <div class="kpi-cell"><div class="kpi-label">Thời gian áp dụng</div><div class="kpi-value mono">${daysCount} ngày</div></div>
    </div>

    <div class="card card-pad">
      <div class="toolbar">
        <input type="search" id="search-input" style="max-width: 340px;" placeholder="Tìm kiếm tiêu đề hoặc nội dung..." value="${escapeHtml(state.search)}" />
        <div style="display:flex; gap:8px; flex-wrap:wrap;">
          <select id="category-select" style="width:auto;">
            ${["Tất cả", "Học tập", "Lịch nhắc", "Dự án", "Ôn tập", "Cá nhân"].map((c) => `<option value="${c}" ${state.category === c ? "selected" : ""}>${c}</option>`).join("")}
          </select>
          <select id="sort-select" style="width:auto;">
            <option value="custom" ${state.sort === "custom" ? "selected" : ""}>Thứ tự tùy chỉnh (↑/↓)</option>
            <option value="schedule_asc" ${state.sort === "schedule_asc" ? "selected" : ""}>Lịch nhắc gần nhất</option>
            <option value="priority_desc" ${state.sort === "priority_desc" ? "selected" : ""}>Ưu tiên cao trước</option>
            <option value="title_asc" ${state.sort === "title_asc" ? "selected" : ""}>Tiêu đề (A → Z)</option>
          </select>
          <button type="button" class="btn-secondary" id="btn-toggle-view">${state.viewMode === "list" ? "Xem lịch 5+ ngày" : "Xem danh sách"}</button>
        </div>
      </div>
    </div>

    <div class="card" id="notes-list-container"></div>
  `;

  document.getElementById("search-input").addEventListener("input", (e) => {
    state.search = e.target.value;
    renderNotesView(root);
  });
  document.getElementById("category-select").addEventListener("change", (e) => {
    state.category = e.target.value;
    renderNotesView(root);
  });
  document.getElementById("sort-select").addEventListener("change", (e) => {
    state.sort = e.target.value;
    renderNotesView(root);
  });
  document.getElementById("btn-toggle-view").addEventListener("click", () => {
    state.viewMode = state.viewMode === "list" ? "timeline" : "list";
    renderNotesView(root);
  });

  const listEl = document.getElementById("notes-list-container");
  if (filtered.length === 0) {
    listEl.innerHTML = `<div class="card-pad" style="text-align:center;color:#64748b;">Không có ghi chú phù hợp.</div>`;
    return;
  }

  listEl.innerHTML = filtered
    .map(
      (n) => `
      <div class="note-row">
        <div style="min-width:0; flex:1;">
          <h3 class="note-title ${n.completed ? "done" : ""}">${escapeHtml(n.title)}</h3>
          <div style="font-size:13px;color:#475569;margin-top:4px;">${escapeHtml(n.content)}</div>
          <div class="note-meta mono">
            ${escapeHtml(n.category)} · ${escapeHtml(n.scheduledDate)} ${escapeHtml(n.scheduledTime)} (${n.durationMinutes}p) · Ưu tiên ${escapeHtml(n.priority)}
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:6px;flex-shrink:0;">
          <button class="btn-secondary" data-action="toggle" data-id="${n.id}">${n.completed ? "Chưa xong" : "Xong"}</button>
          ${
            state.sort === "custom"
              ? `<button class="btn-secondary" data-action="up" data-id="${n.id}">↑</button>
                 <button class="btn-secondary" data-action="down" data-id="${n.id}">↓</button>`
              : ""
          }
          <button class="btn-secondary" data-action="edit" data-id="${n.id}">Sửa</button>
          <button class="btn-danger" data-action="delete" data-id="${n.id}">Xóa</button>
        </div>
      </div>`
    )
    .join("");

  listEl.querySelectorAll("button[data-action]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-id");
      const action = btn.getAttribute("data-action");
      if (action === "toggle") {
        state.notes = state.notes.map((n) => (n.id === id ? { ...n, completed: !n.completed } : n));
        saveStore(STORAGE_KEYS.NOTES, state.notes);
        render();
      } else if (action === "delete") {
        state.notes = state.notes.filter((n) => n.id !== id);
        saveStore(STORAGE_KEYS.NOTES, state.notes);
        showToast("Đã xóa ghi chú khỏi LocalStorage.");
        render();
      } else if (action === "edit") {
        const note = state.notes.find((n) => n.id === id);
        if (note) openNoteModal(note);
      } else if (action === "up" || action === "down") {
        const ordered = [...state.notes].sort((a, b) => a.orderIndex - b.orderIndex);
        const idx = ordered.findIndex((n) => n.id === id);
        const swap = action === "up" ? idx - 1 : idx + 1;
        if (idx >= 0 && swap >= 0 && swap < ordered.length) {
          [ordered[idx], ordered[swap]] = [ordered[swap], ordered[idx]];
          state.notes = ordered.map((item, i) => ({ ...item, orderIndex: i }));
          saveStore(STORAGE_KEYS.NOTES, state.notes);
          render();
        }
      }
    });
  });
}

function renderScheduleView(root) {
  root.innerHTML = `
    <div class="card card-pad">
      <h2 style="margin-top:0;">Lịch trình hàng ngày</h2>
      <div id="schedule-rows">
        ${state.schedule
          .map(
            (b) => `
          <div class="note-row">
            <div>
              <strong class="mono">${escapeHtml(b.startTime)} – ${escapeHtml(b.endTime)}</strong>
              <span style="margin-left:10px;">${escapeHtml(b.label)}</span>
              <div class="note-meta">${escapeHtml(b.status)}</div>
            </div>
            <button class="btn-danger" data-del-blk="${b.id}">Xóa</button>
          </div>`
          )
          .join("")}
      </div>
    </div>
  `;
  root.querySelectorAll("button[data-del-blk]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-del-blk");
      state.schedule = state.schedule.filter((b) => b.id !== id);
      saveStore(STORAGE_KEYS.SCHEDULE, state.schedule);
      render();
    });
  });
}

function renderAICoachView(root) {
  const jsRes = suggestThreeStudySlotsJS(state.notes, state.schedule);
  const avgGoalPct = state.goals.length
    ? Math.round(
        state.goals.reduce((acc, g) => acc + Math.min(100, Math.round((g.completedCount / Math.max(1, g.targetCount)) * 100)), 0) /
          state.goals.length
      )
    : 0;

  root.innerHTML = `
    <div class="card card-pad">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
        <h2 style="margin:0;font-size:16px;">Tỷ lệ hoàn thành mục tiêu hàng tuần</h2>
        <strong class="mono">${avgGoalPct}%</strong>
      </div>
      <div class="progress-track" style="height:12px;">
        <div class="progress-fill" style="width:${avgGoalPct}%"></div>
      </div>
      <div style="display:grid;gap:12px;margin-top:16px;">
        ${state.goals
          .map((g) => {
            const pct = Math.min(100, Math.round((g.completedCount / Math.max(1, g.targetCount)) * 100));
            return `
              <div>
                <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;">
                  <span>${escapeHtml(g.title)} (${g.completedCount}/${g.targetCount} ${escapeHtml(g.unit)})</span>
                  <strong class="mono">${pct}%</strong>
                </div>
                <div class="progress-track">
                  <div class="progress-fill ${pct >= 100 ? "done" : pct < 55 ? "warn" : ""}" style="width:${pct}%"></div>
                </div>
              </div>`;
          })
          .join("")}
      </div>
    </div>

    <div class="card card-pad">
      <h2 style="margin-top:0;font-size:16px;">Phân tích JavaScript — 3 khung giờ học tập từ khoảng trống trong ghi chú</h2>
      <p style="font-size:13px;color:#475569;">Phát hiện ${jsRes.extracted.length} khoảng thời gian trống trong ghi chú.</p>
      <div class="slots-grid">
        ${jsRes.slots
          .map(
            (s) => `
          <div class="slot-card">
            <div>
              <div style="font-size:12px;color:#1d4ed8;font-weight:600;">Khung #${s.order} · ${s.period}</div>
              <div class="mono" style="font-size:18px;font-weight:700;margin:6px 0;">${s.timeRange}</div>
              <div style="font-size:13px;font-weight:600;">${escapeHtml(s.taskTitle)}</div>
              <div style="font-size:12px;color:#64748b;margin-top:4px;">${escapeHtml(s.source)}</div>
            </div>
            <button class="btn-secondary" data-apply-slot="${s.startTime}" data-slot-title="${escapeHtml(s.taskTitle)}" data-slot-dur="${s.durationMinutes}">Đặt lịch nhắc giờ này</button>
          </div>`
          )
          .join("")}
      </div>
    </div>

    <div class="card card-pad">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
        <div>
          <h2 style="margin:0;font-size:16px;">Phân tích chuyên sâu bằng Gemini AI (Python Backend)</h2>
          <p style="margin:4px 0 0;font-size:12px;color:#64748b;">Gửi ghi chú & lịch trình lên endpoint /api/ai/study-coach</p>
        </div>
        <button class="btn-primary" id="btn-run-gemini">Phân tích với Gemini AI</button>
      </div>
      <div id="gemini-output" style="margin-top:14px;font-size:13px;color:#334155;">
        ${state.aiResult ? escapeHtml(state.aiResult.overallAssessment || "") : "Nhấn nút trên để nhận phân tích từ Python Flask + Gemini AI."}
      </div>
    </div>
  `;

  root.querySelectorAll("button[data-apply-slot]").forEach((btn) => {
    btn.addEventListener("click", () => {
      openNoteModal({
        title: `Lịch học: ${btn.getAttribute("data-slot-title")}`,
        content: `Áp dụng theo khung giờ gợi ý ${btn.getAttribute("data-apply-slot")}.`,
        category: "Lịch nhắc",
        priority: "Cao",
        scheduledDate: new Date().toISOString().slice(0, 10),
        scheduledTime: btn.getAttribute("data-apply-slot"),
        durationMinutes: Number(btn.getAttribute("data-slot-dur")) || 60,
      });
    });
  });

  document.getElementById("btn-run-gemini").addEventListener("click", async () => {
    const out = document.getElementById("gemini-output");
    out.textContent = "Đang gọi Python backend /api/ai/study-coach...";
    try {
      const res = await fetch("/api/ai/study-coach", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          notes: state.notes,
          dailySchedule: state.schedule,
          weeklyGoals: state.goals,
          currentDate: new Date().toISOString().slice(0, 10),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Lỗi máy chủ");
      state.aiResult = data;
      renderAICoachView(root);
    } catch (err) {
      out.textContent = `Lỗi: ${err.message}`;
    }
  });
}

function renderGoalsAndGuideView(root) {
  root.innerHTML = `
    <div class="card card-pad">
      <h2 style="margin-top:0;">Theo dõi Mục tiêu Hàng tuần</h2>
      <div style="display:grid;gap:14px;">
        ${state.goals
          .map((g) => {
            const pct = Math.min(100, Math.round((g.completedCount / Math.max(1, g.targetCount)) * 100));
            return `
              <div style="border-bottom:1px solid #e2e8f0;padding-bottom:12px;">
                <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
                  <strong>${escapeHtml(g.title)}</strong>
                  <div style="display:flex;align-items:center;gap:8px;">
                    <button class="btn-secondary" data-goal-delta="-1" data-goal-id="${g.id}">-</button>
                    <span class="mono">${g.completedCount}/${g.targetCount} ${escapeHtml(g.unit)} (${pct}%)</span>
                    <button class="btn-secondary" data-goal-delta="1" data-goal-id="${g.id}">+</button>
                  </div>
                </div>
                <div class="progress-track" style="margin-top:8px;">
                  <div class="progress-fill ${pct >= 100 ? "done" : ""}" style="width:${pct}%"></div>
                </div>
              </div>`;
          })
          .join("")}
      </div>
    </div>

    <div class="card card-pad">
      <h2 style="margin-top:0;">Tài liệu a, b, c — Kiến trúc Python Flask & LocalStorage</h2>
      <p><strong>a) Giao diện chính:</strong> Thanh điều hướng bên trái, thanh tiêu đề trên cùng và khu vực quản lý 12 ghi chú cá nhân trải dài 7 ngày.</p>
      <p><strong>b) Giao diện các chức năng chính:</strong> Thêm, sửa, xóa, tìm kiếm, sắp xếp (tùy chỉnh ↑/↓, lịch nhắc, ưu tiên, A–Z), lịch trình hàng ngày và bảng AI + thanh tiến độ mục tiêu tuần.</p>
      <p><strong>c) Cách vận hành:</strong> Toàn bộ ghi chú được lưu vào <code>localStorage</code> trên trình duyệt; máy chủ Python Flask phục vụ giao diện Jinja2 và gọi Gemini AI qua endpoint <code>/api/ai/study-coach</code>.</p>
    </div>
  `;

  root.querySelectorAll("button[data-goal-delta]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-goal-id");
      const delta = Number(btn.getAttribute("data-goal-delta"));
      state.goals = state.goals.map((g) =>
        g.id === id ? { ...g, completedCount: Math.max(0, g.completedCount + delta) } : g
      );
      saveStore(STORAGE_KEYS.GOALS, state.goals);
      render();
    });
  });
}

function openNoteModal(note = null) {
  const modal = document.getElementById("note-modal");
  const goalSel = document.getElementById("note-goal");
  goalSel.innerHTML = `<option value="">Không liên kết</option>` + state.goals.map((g) => `<option value="${g.id}">${escapeHtml(g.title)}</option>`).join("");

  document.getElementById("modal-heading").textContent = note && note.id ? "Chỉnh sửa ghi chú" : "Thêm ghi chú mới";
  document.getElementById("note-id").value = note?.id || "";
  document.getElementById("note-title").value = note?.title || "";
  document.getElementById("note-content").value = note?.content || "";
  document.getElementById("note-category").value = note?.category || "Học tập";
  document.getElementById("note-priority").value = note?.priority || "Trung bình";
  document.getElementById("note-date").value = note?.scheduledDate || new Date().toISOString().slice(0, 10);
  document.getElementById("note-time").value = note?.scheduledTime || "19:30";
  document.getElementById("note-duration").value = note?.durationMinutes || 60;
  document.getElementById("note-goal").value = note?.goalId || "";
  document.getElementById("note-reminder").checked = note?.reminderEnabled !== false;

  modal.classList.remove("hidden");
}

function render() {
  updateSidebarSummary();
  const root = document.getElementById("workspace-root");
  const titles = {
    notes: "Ghi chú & Lịch nhắc học tập",
    schedule: "Lịch trình hàng ngày",
    ai_coach: "Trợ lý AI Gợi ý giờ học",
    goals_guide: "Mục tiêu tuần & Hướng dẫn",
  };
  document.getElementById("topbar-title").textContent = titles[state.view];

  document.querySelectorAll("[data-view]").forEach((el) => {
    el.classList.toggle("active", el.getAttribute("data-view") === state.view);
  });

  if (state.view === "notes") renderNotesView(root);
  if (state.view === "schedule") renderScheduleView(root);
  if (state.view === "ai_coach") renderAICoachView(root);
  if (state.view === "goals_guide") renderGoalsAndGuideView(root);
}

document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll("[data-view]").forEach((btn) => {
    btn.addEventListener("click", () => {
      state.view = btn.getAttribute("data-view");
      render();
    });
  });

  document.getElementById("btn-open-create").addEventListener("click", () => openNoteModal(null));
  document.getElementById("btn-close-modal").addEventListener("click", () => document.getElementById("note-modal").classList.add("hidden"));
  document.getElementById("btn-cancel-modal").addEventListener("click", () => document.getElementById("note-modal").classList.add("hidden"));

  document.getElementById("note-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const id = document.getElementById("note-id").value;
    const item = {
      title: document.getElementById("note-title").value.trim(),
      content: document.getElementById("note-content").value.trim(),
      category: document.getElementById("note-category").value,
      priority: document.getElementById("note-priority").value,
      scheduledDate: document.getElementById("note-date").value,
      scheduledTime: document.getElementById("note-time").value,
      durationMinutes: Number(document.getElementById("note-duration").value) || 60,
      goalId: document.getElementById("note-goal").value || undefined,
      reminderEnabled: document.getElementById("note-reminder").checked,
    };

    if (id) {
      state.notes = state.notes.map((n) => (n.id === id ? { ...n, ...item } : n));
      showToast("Đã cập nhật ghi chú trong LocalStorage.");
    } else {
      const maxOrder = state.notes.reduce((m, n) => Math.max(m, n.orderIndex), -1);
      state.notes.unshift({ ...item, id: `n-${Date.now()}`, completed: false, orderIndex: maxOrder + 1 });
      showToast("Đã thêm ghi chú mới vào LocalStorage.");
    }

    saveStore(STORAGE_KEYS.NOTES, state.notes);
    document.getElementById("note-modal").classList.add("hidden");
    render();
  });

  render();
});
