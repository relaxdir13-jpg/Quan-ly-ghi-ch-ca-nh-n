# Sổ Tay Học Tập — Phiên bản Python Web (Flask)

Ứng dụng web quản lý ghi chú cá nhân được xây dựng bằng **Python (Flask)** kết hợp **LocalStorage** và **Trợ lý AI (JavaScript + Gemini API)**.

## Cấu trúc thư mục
- `app.py`: Máy chủ Flask phục vụ giao diện web và API `/api/ai/study-coach`.
- `requirements.txt`: Danh sách thư viện Python (`flask`, `google-genai`, `python-dotenv`).
- `templates/index.html`: Giao diện Jinja2 chính.
- `static/styles.css`: Định dạng giao diện bảng điều khiển.
- `static/app.js`: Xử lý `localStorage`, CRUD 12 ghi chú (7 ngày), sắp xếp, trích xuất khung giờ trống bằng JavaScript và thanh tiến độ mục tiêu tuần.

## Hướng dẫn cài đặt và chạy
```bash
cd python_app
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
export GEMINI_API_KEY="your_api_key_here"
python app.py
```
Truy cập `http://localhost:5000`.
