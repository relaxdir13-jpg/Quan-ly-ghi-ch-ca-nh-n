import 'dotenv/config';
import express from 'express';
import type { Request, Response } from 'express';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(express.json({ limit: '1mb' }));

interface NotePayload {
  id: string;
  title: string;
  content: string;
  category: string;
  priority: string;
  scheduledDate: string;
  scheduledTime: string;
  durationMinutes: number;
  completed: boolean;
}

interface DailyBlockPayload {
  id: string;
  startTime: string;
  endTime: string;
  label: string;
  status: string;
}

interface WeeklyGoalPayload {
  id: string;
  title: string;
  category: string;
  targetCount: number;
  completedCount: number;
  unit: string;
}

function sanitizeText(value: unknown, maxLen = 500): string {
  if (typeof value !== 'string') return '';
  return value.trim().slice(0, maxLen);
}

const PYTHON_APP_FILES = [
  'app.py',
  'requirements.txt',
  'templates/index.html',
  'static/app.js',
  'static/styles.css',
  'README.md',
] as const;

app.get('/api/health', (_req: Request, res: Response) => {
  res.json({ ok: true, timestamp: new Date().toISOString() });
});

app.get('/api/python-files', async (_req: Request, res: Response) => {
  try {
    const baseDir = path.resolve(__dirname, 'python_app');
    const files = await Promise.all(
      PYTHON_APP_FILES.map(async (relPath) => {
        const resolved = path.resolve(baseDir, relPath);
        if (!resolved.startsWith(baseDir + path.sep)) {
          throw new Error('Invalid file path');
        }
        const content = await fs.readFile(resolved, 'utf8');
        return { path: `python_app/${relPath}`, filename: path.basename(relPath), content };
      })
    );
    res.json({ files });
  } catch (err) {
    console.error('Failed to read python_app files:', err);
    res.status(500).json({ error: 'Không thể đọc danh sách tệp mã nguồn Python.' });
  }
});

app.post('/api/ai/study-coach', async (req: Request, res: Response) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(500).json({
        error: 'Chưa cấu hình GEMINI_API_KEY trên máy chủ. Vui lòng thiết lập khóa trong phần Settings > Secrets.',
      });
      return;
    }

    const body = req.body as {
      notes?: unknown;
      dailySchedule?: unknown;
      weeklyGoals?: unknown;
      customPrompt?: unknown;
      currentDate?: unknown;
    };

    if (!Array.isArray(body?.notes) || !Array.isArray(body?.dailySchedule) || !Array.isArray(body?.weeklyGoals)) {
      res.status(400).json({
        error: 'Dữ liệu đầu vào không hợp lệ. Cần danh sách ghi chú, lịch trình hàng ngày và mục tiêu tuần.',
      });
      return;
    }

    const notes: NotePayload[] = body.notes.slice(0, 60).map((n: Record<string, unknown>) => ({
      id: sanitizeText(n.id, 64),
      title: sanitizeText(n.title, 160),
      content: sanitizeText(n.content, 600),
      category: sanitizeText(n.category, 40),
      priority: sanitizeText(n.priority, 20),
      scheduledDate: sanitizeText(n.scheduledDate, 20),
      scheduledTime: sanitizeText(n.scheduledTime, 10),
      durationMinutes: typeof n.durationMinutes === 'number' ? Math.max(15, Math.min(360, n.durationMinutes)) : 60,
      completed: Boolean(n.completed),
    }));

    const dailySchedule: DailyBlockPayload[] = body.dailySchedule.slice(0, 30).map((b: Record<string, unknown>) => ({
      id: sanitizeText(b.id, 64),
      startTime: sanitizeText(b.startTime, 10),
      endTime: sanitizeText(b.endTime, 10),
      label: sanitizeText(b.label, 120),
      status: sanitizeText(b.status, 30),
    }));

    const weeklyGoals: WeeklyGoalPayload[] = body.weeklyGoals.slice(0, 20).map((g: Record<string, unknown>) => ({
      id: sanitizeText(g.id, 64),
      title: sanitizeText(g.title, 140),
      category: sanitizeText(g.category, 40),
      targetCount: typeof g.targetCount === 'number' ? Math.max(1, Math.min(100, g.targetCount)) : 1,
      completedCount: typeof g.completedCount === 'number' ? Math.max(0, Math.min(100, g.completedCount)) : 0,
      unit: sanitizeText(g.unit, 20),
    }));

    const customPrompt = sanitizeText(body.customPrompt, 400);
    const currentDate = sanitizeText(body.currentDate, 20) || new Date().toISOString().slice(0, 10);

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const systemInstruction = [
      'Bạn là Trợ lý AI Quản lý Học tập cá nhân thông minh, súc tích và thực tế.',
      'Nhiệm vụ của bạn:',
      '1. Đọc kỹ toàn bộ nội dung các ghi chú học tập (chú ý phát hiện các khoảng thời gian trống mà người dùng ghi trong nội dung ghi chú như "rảnh 19:00-21:00", "trống 14h-16h", v.v.) kết hợp với Lịch trình hàng ngày.',
      '2. Đề xuất ĐÚNG 3 khung giờ học tập hiệu quả nhất trong ngày (tối ưu năng lượng, xen kẽ nghỉ ngơi, khớp với khoảng trống thực tế và ưu tiên các ghi chú chưa hoàn thành có mức ưu tiên Cao).',
      '3. Đánh giá tỷ lệ hoàn thành mục tiêu hàng tuần và đưa ra lời khuyên hành động cụ thể bằng tiếng Việt tự nhiên, không dùng từ ngữ máy móc.',
    ].join('\n');

    const promptText = `
Ngày hiện tại: ${currentDate}
Yêu cầu bổ sung của người dùng: ${customPrompt || 'Không có yêu cầu thêm'}

=== LỊCH TRÌNH HÀNG NGÀY ===
${JSON.stringify(dailySchedule, null, 2)}

=== DANH SÁCH GHI CHÚ & LỊCH NHẮC ===
${JSON.stringify(notes, null, 2)}

=== MỤC TIÊU HÀNG TUẦN ===
${JSON.stringify(weeklyGoals, null, 2)}

Hãy phân tích kỹ các khoảng thời gian trống từ ghi chú và lịch trình, gợi ý đúng 3 khung giờ học tập hiệu quả nhất trong ngày, và đánh giá tiến độ mục tiêu tuần.
`.trim();

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            overallAssessment: {
              type: Type.STRING,
              description: 'Nhận xét tổng quan ngắn gọn về khối lượng ghi chú, các khoảng trống tìm được và tiến độ tuần.',
            },
            extractedFreeWindows: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Danh sách các khoảng thời gian trống phát hiện được từ nội dung ghi chú và lịch trình (ví dụ: "19:30 - 21:30 (từ ghi chú)").',
            },
            suggestedSlots: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  slotOrder: { type: Type.INTEGER, description: 'Thứ tự khung giờ 1, 2, hoặc 3' },
                  dayLabel: { type: Type.STRING, description: 'Nhãn ngày áp dụng (ví dụ: Hôm nay 25/11 hoặc Ngày mai 26/11)' },
                  recommendedDate: { type: Type.STRING, description: 'Ngày YYYY-MM-DD' },
                  startTime: { type: Type.STRING, description: 'Giờ bắt đầu HH:mm' },
                  timeRange: { type: Type.STRING, description: 'Khoảng giờ ví dụ 19:30 - 21:00' },
                  durationMinutes: { type: Type.INTEGER, description: 'Thời lượng phút (ví dụ 60 hoặc 90)' },
                  focusTopic: { type: Type.STRING, description: 'Chủ đề học tập nên ưu tiên trong khung giờ này' },
                  linkedNoteTitle: { type: Type.STRING, description: 'Tên ghi chú liên quan trong danh sách (nếu có)' },
                  reason: { type: Type.STRING, description: 'Lý do chọn khung giờ này dựa trên khoảng trống và mức độ ưu tiên' },
                },
              },
              description: 'Đúng 3 khung giờ học tập hiệu quả nhất trong ngày được gợi ý.',
            },
            weeklyGoalAnalysis: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  goalTitle: { type: Type.STRING },
                  completionPercent: { type: Type.INTEGER },
                  status: { type: Type.STRING, description: 'Đạt mục tiêu | Đúng tiến độ | Cần tăng tốc' },
                  actionableTip: { type: Type.STRING },
                },
              },
            },
            scheduleTip: {
              type: Type.STRING,
              description: 'Một lời khuyên ngắn gọn để duy trì nhịp học tập bền vững.',
            },
          },
        },
      },
    });

    const rawText = response.text;
    if (!rawText) {
      res.status(502).json({ error: 'Gemini AI không trả về nội dung phân tích. Vui lòng thử lại.' });
      return;
    }

    const parsed = JSON.parse(rawText);
    res.json(parsed);
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Lỗi không xác định từ máy chủ AI';
    console.error('Gemini study-coach error:', err);
    res.status(500).json({
      error: `Không thể kết nối Trợ lý Gemini AI: ${message}`,
    });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
}

startServer();
