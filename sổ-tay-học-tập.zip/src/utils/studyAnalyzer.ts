import type {
  DailyScheduleBlock,
  JSExtractedWindow,
  JSSuggestedSlot,
  NoteItem,
  WeeklyGoal,
} from '../types/notes';

function toMinutes(hhmm: string): number {
  const [hStr, mStr] = hhmm.split(':');
  const h = Number(hStr);
  const m = Number(mStr || '0');
  if (Number.isNaN(h) || Number.isNaN(m)) return -1;
  return h * 60 + m;
}

function formatHHMM(totalMinutes: number): string {
  const clamped = Math.max(0, Math.min(23 * 60 + 59, totalMinutes));
  const h = Math.floor(clamped / 60);
  const m = clamped % 60;
  return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

function getPeriodLabel(startMinutes: number): 'Buổi sáng' | 'Buổi chiều' | 'Buổi tối' {
  if (startMinutes < 12 * 60) return 'Buổi sáng';
  if (startMinutes < 18 * 60) return 'Buổi chiều';
  return 'Buổi tối';
}

function priorityScore(priority: NoteItem['priority']): number {
  if (priority === 'Cao') return 3;
  if (priority === 'Trung bình') return 2;
  return 1;
}

/**
 * Extracts free-time intervals mentioned inside the user's note text using JavaScript RegExp.
 * Supports formats like:
 * - "06:30 - 07:45", "19:30-21:30"
 * - "14h - 16h30", "19h30-21h"
 * - "từ 14:15 đến 16:00"
 */
export function extractFreeWindowsFromNotes(notes: NoteItem[]): JSExtractedWindow[] {
  const results: JSExtractedWindow[] = [];
  const seenKeys = new Set<string>();

  // Match patterns like "06:30 - 07:45", "14h15 - 16h00", "từ 19h đến 21h30"
  const timeRangeRegex =
    /(?:từ\s*)?(\d{1,2})\s*[:h]\s*(\d{0,2})\s*(?:-|–|đến|to)\s*(\d{1,2})\s*[:h]\s*(\d{0,2})/gi;

  for (const note of notes) {
    const combinedText = `${note.title} ${note.content}`;
    let match: RegExpExecArray | null;
    timeRangeRegex.lastIndex = 0;

    while ((match = timeRangeRegex.exec(combinedText)) !== null) {
      const sh = Number(match[1]);
      const sm = match[2] ? Number(match[2]) : 0;
      const eh = Number(match[3]);
      const em = match[4] ? Number(match[4]) : 0;

      if (sh > 23 || eh > 23 || sm > 59 || em > 59) continue;

      const startMinutes = sh * 60 + sm;
      const endMinutes = eh * 60 + em;
      const duration = endMinutes - startMinutes;

      if (duration < 25 || duration > 360) continue;

      const startTime = formatHHMM(startMinutes);
      const endTime = formatHHMM(endMinutes);
      const dedupKey = `${startTime}-${endTime}-${note.id}`;

      if (!seenKeys.has(dedupKey)) {
        seenKeys.add(dedupKey);
        results.push({
          sourceNoteId: note.id,
          sourceNoteTitle: note.title,
          startTime,
          endTime,
          durationMinutes: duration,
          rawMatch: match[0].trim(),
          periodLabel: getPeriodLabel(startMinutes),
        });
      }
    }
  }

  return results.sort((a, b) => toMinutes(a.startTime) - toMinutes(b.startTime));
}

/**
 * JavaScript study analyzer:
 * 1. Scans notes for user-entered free-time windows.
 * 2. Combines with daily free schedule blocks if needed to guarantee 3 distinct daily study slots.
 * 3. Matches each slot with the highest-priority incomplete note.
 */
export function analyzeStudyScheduleWithJS(
  notes: NoteItem[],
  dailySchedule: DailyScheduleBlock[]
): {
  extractedFromNotes: JSExtractedWindow[];
  suggestedSlots: JSSuggestedSlot[];
  summaryText: string;
} {
  const extractedFromNotes = extractFreeWindowsFromNotes(notes);
  const pendingNotes = [...notes]
    .filter((n) => !n.completed)
    .sort((a, b) => {
      const pDiff = priorityScore(b.priority) - priorityScore(a.priority);
      if (pDiff !== 0) return pDiff;
      return `${a.scheduledDate} ${a.scheduledTime}`.localeCompare(
        `${b.scheduledDate} ${b.scheduledTime}`
      );
    });

  // Candidate pool: note-extracted free slots first, then daily schedule free slots
  interface CandidateSlot {
    startTime: string;
    endTime: string;
    durationMinutes: number;
    periodLabel: 'Buổi sáng' | 'Buổi chiều' | 'Buổi tối';
    sourceLabel: string;
    preferredNoteId?: string;
    priorityWeight: number;
  }

  const candidates: CandidateSlot[] = [];

  for (const w of extractedFromNotes) {
    candidates.push({
      startTime: w.startTime,
      endTime: w.endTime,
      durationMinutes: w.durationMinutes,
      periodLabel: w.periodLabel,
      sourceLabel: `Trích từ ghi chú "${w.sourceNoteTitle}"`,
      preferredNoteId: w.sourceNoteId,
      priorityWeight: 2,
    });
  }

  for (const blk of dailySchedule) {
    if (blk.status !== 'Rảnh - Có thể học') continue;
    const startMin = toMinutes(blk.startTime);
    const endMin = toMinutes(blk.endTime);
    const duration = endMin - startMin;
    if (startMin < 0 || duration < 30) continue;

    candidates.push({
      startTime: blk.startTime,
      endTime: blk.endTime,
      durationMinutes: duration,
      periodLabel: getPeriodLabel(startMin),
      sourceLabel: `Từ lịch trình: ${blk.label}`,
      priorityWeight: 1,
    });
  }

  // Pick up to 3 distinct slots preferring diversity across Buổi sáng, Buổi chiều, Buổi tối
  const picked: CandidateSlot[] = [];
  const usedPeriods = new Set<string>();
  const usedRanges = new Set<string>();

  // Pass 1: pick best candidate per period (morning, afternoon, evening)
  const sortedCandidates = [...candidates].sort((a, b) => {
    if (b.priorityWeight !== a.priorityWeight) return b.priorityWeight - a.priorityWeight;
    return b.durationMinutes - a.durationMinutes;
  });

  for (const cand of sortedCandidates) {
    if (picked.length >= 3) break;
    const rangeKey = `${cand.startTime}-${cand.endTime}`;
    if (!usedPeriods.has(cand.periodLabel) && !usedRanges.has(rangeKey)) {
      picked.push(cand);
      usedPeriods.add(cand.periodLabel);
      usedRanges.add(rangeKey);
    }
  }

  // Pass 2: if fewer than 3, fill remaining from non-duplicate time ranges
  for (const cand of sortedCandidates) {
    if (picked.length >= 3) break;
    const rangeKey = `${cand.startTime}-${cand.endTime}`;
    if (!usedRanges.has(rangeKey)) {
      picked.push(cand);
      usedRanges.add(rangeKey);
    }
  }

  // Fallback if user cleared both notes and schedule completely
  const defaultFallbacks: CandidateSlot[] = [
    {
      startTime: '06:30',
      endTime: '07:30',
      durationMinutes: 60,
      periodLabel: 'Buổi sáng',
      sourceLabel: 'Khung gợi ý mặc định (Sáng)',
      priorityWeight: 0,
    },
    {
      startTime: '14:30',
      endTime: '16:00',
      durationMinutes: 90,
      periodLabel: 'Buổi chiều',
      sourceLabel: 'Khung gợi ý mặc định (Chiều)',
      priorityWeight: 0,
    },
    {
      startTime: '19:30',
      endTime: '21:00',
      durationMinutes: 90,
      periodLabel: 'Buổi tối',
      sourceLabel: 'Khung gợi ý mặc định (Tối)',
      priorityWeight: 0,
    },
  ];

  for (const fb of defaultFallbacks) {
    if (picked.length >= 3) break;
    const rangeKey = `${fb.startTime}-${fb.endTime}`;
    if (!usedRanges.has(rangeKey)) {
      picked.push(fb);
      usedRanges.add(rangeKey);
    }
  }

  picked.sort((a, b) => toMinutes(a.startTime) - toMinutes(b.startTime));

  const assignedNoteIds = new Set<string>();
  const suggestedSlots: JSSuggestedSlot[] = picked.map((slot, idx) => {
    // Find best incomplete note not yet assigned
    let matchedNote = pendingNotes.find(
      (n) => n.id === slot.preferredNoteId && !assignedNoteIds.has(n.id)
    );
    if (!matchedNote) {
      matchedNote = pendingNotes.find((n) => !assignedNoteIds.has(n.id));
    }
    if (matchedNote) {
      assignedNoteIds.add(matchedNote.id);
    }

    const recommendedTaskTitle = matchedNote
      ? matchedNote.title
      : 'Ôn tập kiến thức trọng tâm & rà soát ghi chú tuần';

    const scoreReason = matchedNote
      ? `Phù hợp với khoảng trống ${slot.durationMinutes} phút (${slot.periodLabel.toLowerCase()}) để xử lý việc ưu tiên "${matchedNote.priority}".`
      : `Khung thời gian ${slot.periodLabel.toLowerCase()} yên tĩnh (${slot.durationMinutes} phút), thích hợp để đọc lại ghi chú và củng cố kiến thức.`;

    return {
      slotOrder: idx + 1,
      startTime: slot.startTime,
      endTime: slot.endTime,
      timeRange: `${slot.startTime} – ${slot.endTime}`,
      durationMinutes: slot.durationMinutes,
      periodLabel: slot.periodLabel,
      sourceLabel: slot.sourceLabel,
      recommendedTaskTitle,
      linkedNoteId: matchedNote?.id,
      scoreReason,
    };
  });

  const summaryText = `Bộ phân tích JavaScript đã quét ${notes.length} ghi chú, phát hiện ${extractedFromNotes.length} khoảng thời gian trống được ghi trực tiếp trong nội dung ghi chú và chọn ra 3 khung giờ học tối ưu trong ngày cho ${pendingNotes.length} đầu việc chưa hoàn thành.`;

  return {
    extractedFromNotes,
    suggestedSlots,
    summaryText,
  };
}

export function computeGoalProgress(goal: WeeklyGoal): {
  percent: number;
  statusLabel: 'Đạt mục tiêu' | 'Đúng tiến độ' | 'Cần tăng tốc';
} {
  const safeTarget = Math.max(1, goal.targetCount);
  const rawPct = Math.round((goal.completedCount / safeTarget) * 100);
  const percent = Math.max(0, Math.min(100, rawPct));

  let statusLabel: 'Đạt mục tiêu' | 'Đúng tiến độ' | 'Cần tăng tốc' = 'Cần tăng tốc';
  if (percent >= 100) {
    statusLabel = 'Đạt mục tiêu';
  } else if (percent >= 55) {
    statusLabel = 'Đúng tiến độ';
  }

  return { percent, statusLabel };
}

export function computeOverallWeeklyProgress(goals: WeeklyGoal[]): number {
  if (goals.length === 0) return 0;
  const total = goals.reduce((acc, g) => acc + computeGoalProgress(g).percent, 0);
  return Math.round(total / goals.length);
}
