import {
  SEED_DAILY_SCHEDULE,
  SEED_NOTES,
  SEED_WEEKLY_GOALS,
} from '../data/seedData';
import type {
  AIStudyCoachResult,
  DailyScheduleBlock,
  NoteItem,
  WeeklyGoal,
} from '../types/notes';

export const STORAGE_KEYS = {
  NOTES: 'study_notes_manager_notes_v1',
  SCHEDULE: 'study_notes_manager_schedule_v1',
  GOALS: 'study_notes_manager_goals_v1',
  AI_RESULT: 'study_notes_manager_ai_v1',
} as const;

function safeRead<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as T;
    return parsed ?? fallback;
  } catch {
    return fallback;
  }
}

function safeWrite<T>(key: string, value: T): void {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error('LocalStorage write failed:', err);
  }
}

export function loadNotes(): NoteItem[] {
  const stored = safeRead<NoteItem[] | null>(STORAGE_KEYS.NOTES, null);
  if (!stored || !Array.isArray(stored) || stored.length === 0) {
    safeWrite(STORAGE_KEYS.NOTES, SEED_NOTES);
    return SEED_NOTES;
  }
  return stored;
}

export function saveNotes(notes: NoteItem[]): void {
  safeWrite(STORAGE_KEYS.NOTES, notes);
}

export function loadSchedule(): DailyScheduleBlock[] {
  const stored = safeRead<DailyScheduleBlock[] | null>(STORAGE_KEYS.SCHEDULE, null);
  if (!stored || !Array.isArray(stored) || stored.length === 0) {
    safeWrite(STORAGE_KEYS.SCHEDULE, SEED_DAILY_SCHEDULE);
    return SEED_DAILY_SCHEDULE;
  }
  return stored;
}

export function saveSchedule(blocks: DailyScheduleBlock[]): void {
  safeWrite(STORAGE_KEYS.SCHEDULE, blocks);
}

export function loadGoals(): WeeklyGoal[] {
  const stored = safeRead<WeeklyGoal[] | null>(STORAGE_KEYS.GOALS, null);
  if (!stored || !Array.isArray(stored) || stored.length === 0) {
    safeWrite(STORAGE_KEYS.GOALS, SEED_WEEKLY_GOALS);
    return SEED_WEEKLY_GOALS;
  }
  return stored;
}

export function saveGoals(goals: WeeklyGoal[]): void {
  safeWrite(STORAGE_KEYS.GOALS, goals);
}

export function loadCachedAIResult(): AIStudyCoachResult | null {
  return safeRead<AIStudyCoachResult | null>(STORAGE_KEYS.AI_RESULT, null);
}

export function saveCachedAIResult(result: AIStudyCoachResult | null): void {
  if (!result) {
    window.localStorage.removeItem(STORAGE_KEYS.AI_RESULT);
    return;
  }
  safeWrite(STORAGE_KEYS.AI_RESULT, result);
}

export function resetAllToSeedData(): {
  notes: NoteItem[];
  schedule: DailyScheduleBlock[];
  goals: WeeklyGoal[];
} {
  saveNotes(SEED_NOTES);
  saveSchedule(SEED_DAILY_SCHEDULE);
  saveGoals(SEED_WEEKLY_GOALS);
  saveCachedAIResult(null);
  return {
    notes: SEED_NOTES,
    schedule: SEED_DAILY_SCHEDULE,
    goals: SEED_WEEKLY_GOALS,
  };
}

export function formatDateVN(dateStr: string): string {
  if (!dateStr) return 'Chưa đặt ngày';
  const parts = dateStr.split('-');
  if (parts.length !== 3) return dateStr;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

export function getWeekdayVN(dateStr: string): string {
  if (!dateStr) return '';
  const date = new Date(`${dateStr}T00:00:00`);
  if (Number.isNaN(date.getTime())) return '';
  const days = ['Chủ nhật', 'Thứ 2', 'Thứ 3', 'Thứ 4', 'Thứ 5', 'Thứ 6', 'Thứ 7'];
  return days[date.getDay()];
}

export function getTodayISO(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

export function getSpanDaysCount(notes: NoteItem[]): number {
  const uniqueDates = new Set(notes.map((n) => n.scheduledDate).filter(Boolean));
  if (uniqueDates.size <= 1) return uniqueDates.size;
  const timestamps = Array.from(uniqueDates)
    .map((d) => new Date(`${d}T00:00:00`).getTime())
    .filter((t) => !Number.isNaN(t));
  if (timestamps.length === 0) return 0;
  const min = Math.min(...timestamps);
  const max = Math.max(...timestamps);
  return Math.round((max - min) / (1000 * 60 * 60 * 24)) + 1;
}
