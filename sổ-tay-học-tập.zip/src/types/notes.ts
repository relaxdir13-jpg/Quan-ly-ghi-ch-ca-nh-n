export type NoteCategory = 'Học tập' | 'Lịch nhắc' | 'Dự án' | 'Ôn tập' | 'Cá nhân';

export type NotePriority = 'Cao' | 'Trung bình' | 'Thấp';

export type SortOption =
  | 'custom'
  | 'schedule_asc'
  | 'schedule_desc'
  | 'priority_desc'
  | 'title_asc'
  | 'status_pending_first'
  | 'updated_desc';

export type ActiveView = 'notes' | 'schedule' | 'ai_coach' | 'goals_guide' | 'python_source';

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  category: NoteCategory;
  priority: NotePriority;
  scheduledDate: string; // YYYY-MM-DD
  scheduledTime: string; // HH:mm
  durationMinutes: number;
  completed: boolean;
  reminderEnabled: boolean;
  orderIndex: number;
  goalId?: string;
  createdAt: string;
  updatedAt: string;
}

export type ScheduleBlockStatus = 'Rảnh - Có thể học' | 'Bận' | 'Nghỉ ngơi';

export interface DailyScheduleBlock {
  id: string;
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  label: string;
  status: ScheduleBlockStatus;
}

export interface WeeklyGoal {
  id: string;
  title: string;
  category: NoteCategory;
  targetCount: number;
  completedCount: number;
  unit: string; // e.g., 'buổi', 'giờ', 'bài'
  weekRangeLabel: string;
}

export interface AISuggestedSlot {
  slotOrder: number;
  dayLabel: string;
  recommendedDate: string;
  startTime: string;
  timeRange: string;
  durationMinutes: number;
  focusTopic: string;
  linkedNoteTitle: string;
  reason: string;
}

export interface AIGoalAnalysis {
  goalTitle: string;
  completionPercent: number;
  status: string;
  actionableTip: string;
}

export interface AIStudyCoachResult {
  overallAssessment: string;
  extractedFreeWindows: string[];
  suggestedSlots: AISuggestedSlot[];
  weeklyGoalAnalysis: AIGoalAnalysis[];
  scheduleTip: string;
  generatedAt?: string;
}

export interface JSExtractedWindow {
  sourceNoteId: string;
  sourceNoteTitle: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  rawMatch: string;
  periodLabel: 'Buổi sáng' | 'Buổi chiều' | 'Buổi tối';
}

export interface JSSuggestedSlot {
  slotOrder: number;
  startTime: string;
  endTime: string;
  timeRange: string;
  durationMinutes: number;
  periodLabel: string;
  sourceLabel: string;
  recommendedTaskTitle: string;
  linkedNoteId?: string;
  scoreReason: string;
}
