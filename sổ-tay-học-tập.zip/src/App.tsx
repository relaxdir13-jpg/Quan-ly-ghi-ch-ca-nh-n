import { useEffect, useState } from 'react';
import { Menu, Plus } from 'lucide-react';
import { AICoachView } from './components/AICoachView';
import { DailyScheduleView } from './components/DailyScheduleView';
import { NoteFormModal } from './components/NoteFormModal';
import { NotesWorkspace } from './components/NotesWorkspace';
import { PythonSourceView } from './components/PythonSourceView';
import { Sidebar } from './components/Sidebar';
import { WeeklyGoalsAndGuideView } from './components/WeeklyGoalsAndGuideView';
import type {
  AIStudyCoachResult,
  ActiveView,
  DailyScheduleBlock,
  NoteItem,
  ScheduleBlockStatus,
  WeeklyGoal,
} from './types/notes';
import {
  loadCachedAIResult,
  loadGoals,
  loadNotes,
  loadSchedule,
  resetAllToSeedData,
  saveCachedAIResult,
  saveGoals,
  saveNotes,
  saveSchedule,
} from './utils/storage';

const VIEW_LABELS: Record<ActiveView, string> = {
  notes: 'Ghi chú & Lịch nhắc học tập',
  schedule: 'Lịch trình hàng ngày',
  ai_coach: 'Trợ lý AI Gợi ý giờ học',
  goals_guide: 'Mục tiêu tuần & Hướng dẫn',
  python_source: 'Mã nguồn Python (Flask)',
};

export default function App() {
  const [activeView, setActiveView] = useState<ActiveView>('notes');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const [notes, setNotes] = useState<NoteItem[]>(() => loadNotes());
  const [dailySchedule, setDailySchedule] = useState<DailyScheduleBlock[]>(() =>
    loadSchedule()
  );
  const [weeklyGoals, setWeeklyGoals] = useState<WeeklyGoal[]>(() => loadGoals());
  const [cachedAIResult, setCachedAIResult] = useState<AIStudyCoachResult | null>(
    () => loadCachedAIResult()
  );

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingNote, setEditingNote] = useState<NoteItem | null>(null);
  const [prefillSchedule, setPrefillSchedule] = useState<{
    title?: string;
    scheduledDate?: string;
    scheduledTime?: string;
    durationMinutes?: number;
    content?: string;
  } | null>(null);

  const [toastMsg, setToastMsg] = useState<string | null>(null);

  useEffect(() => {
    saveNotes(notes);
  }, [notes]);

  useEffect(() => {
    saveSchedule(dailySchedule);
  }, [dailySchedule]);

  useEffect(() => {
    saveGoals(weeklyGoals);
  }, [weeklyGoals]);

  useEffect(() => {
    if (!toastMsg) return;
    const timer = window.setTimeout(() => setToastMsg(null), 3200);
    return () => window.clearTimeout(timer);
  }, [toastMsg]);

  const showToast = (msg: string) => {
    setToastMsg(msg);
  };

  const handleSaveNote = (
    data: Omit<NoteItem, 'id' | 'createdAt' | 'updatedAt' | 'orderIndex'>,
    existingId?: string
  ) => {
    const nowISO = new Date().toISOString();

    if (existingId) {
      setNotes((prev) =>
        prev.map((n) =>
          n.id === existingId ? { ...n, ...data, updatedAt: nowISO } : n
        )
      );
      showToast('Đã cập nhật ghi chú và lưu vào LocalStorage.');
    } else {
      const maxOrder = notes.reduce(
        (max, item) => Math.max(max, item.orderIndex),
        -1
      );
      const newNote: NoteItem = {
        ...data,
        id: `note-${Date.now()}`,
        orderIndex: maxOrder + 1,
        createdAt: nowISO,
        updatedAt: nowISO,
      };
      setNotes((prev) => [newNote, ...prev]);
      showToast('Đã thêm ghi chú mới vào LocalStorage.');
    }
  };

  const handleToggleComplete = (id: string) => {
    const target = notes.find((n) => n.id === id);
    if (!target) return;
    const nextCompleted = !target.completed;
    const nowISO = new Date().toISOString();

    setNotes((prev) =>
      prev.map((n) =>
        n.id === id ? { ...n, completed: nextCompleted, updatedAt: nowISO } : n
      )
    );

    if (target.goalId) {
      setWeeklyGoals((prev) =>
        prev.map((g) => {
          if (g.id !== target.goalId) return g;
          const delta = nextCompleted ? 1 : -1;
          return {
            ...g,
            completedCount: Math.max(0, g.completedCount + delta),
          };
        })
      );
    }

    showToast(
      nextCompleted
        ? 'Đã đánh dấu hoàn thành ghi chú.'
        : 'Đã chuyển ghi chú về trạng thái chưa xong.'
    );
  };

  const handleDeleteNote = (id: string) => {
    setNotes((prev) => prev.filter((n) => n.id !== id));
    showToast('Đã xóa ghi chú khỏi LocalStorage.');
  };

  const handleMoveNote = (id: string, direction: 'up' | 'down') => {
    setNotes((prev) => {
      const ordered = [...prev].sort((a, b) => a.orderIndex - b.orderIndex);
      const idx = ordered.findIndex((n) => n.id === id);
      if (idx < 0) return prev;
      const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
      if (swapIdx < 0 || swapIdx >= ordered.length) return prev;

      const temp = ordered[idx];
      ordered[idx] = ordered[swapIdx];
      ordered[swapIdx] = temp;

      return ordered.map((item, i) => ({ ...item, orderIndex: i }));
    });
  };

  const handleResetSeedData = () => {
    const restored = resetAllToSeedData();
    setNotes(restored.notes);
    setDailySchedule(restored.schedule);
    setWeeklyGoals(restored.goals);
    setCachedAIResult(null);
    showToast('Đã khôi phục 12 ghi chú mẫu (7 ngày) vào LocalStorage.');
  };

  const handleAddScheduleBlock = (block: Omit<DailyScheduleBlock, 'id'>) => {
    const newBlock: DailyScheduleBlock = {
      ...block,
      id: `blk-${Date.now()}`,
    };
    setDailySchedule((prev) => [...prev, newBlock]);
    showToast('Đã thêm khung giờ vào lịch trình hàng ngày.');
  };

  const handleUpdateScheduleStatus = (id: string, status: ScheduleBlockStatus) => {
    setDailySchedule((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status } : b))
    );
  };

  const handleDeleteScheduleBlock = (id: string) => {
    setDailySchedule((prev) => prev.filter((b) => b.id !== id));
  };

  const handleAddGoal = (goal: Omit<WeeklyGoal, 'id'>) => {
    const newGoal: WeeklyGoal = {
      ...goal,
      id: `goal-${Date.now()}`,
    };
    setWeeklyGoals((prev) => [...prev, newGoal]);
    showToast('Đã thêm mục tiêu tuần mới.');
  };

  const handleAdjustGoalProgress = (id: string, delta: number) => {
    setWeeklyGoals((prev) =>
      prev.map((g) =>
        g.id === id
          ? { ...g, completedCount: Math.max(0, g.completedCount + delta) }
          : g
      )
    );
  };

  const handleDeleteGoal = (id: string) => {
    setWeeklyGoals((prev) => prev.filter((g) => g.id !== id));
    showToast('Đã xóa mục tiêu tuần.');
  };

  const handleSaveAIResult = (result: AIStudyCoachResult) => {
    setCachedAIResult(result);
    saveCachedAIResult(result);
  };

  const handleApplySlotAsNote = (slot: {
    title: string;
    scheduledDate: string;
    scheduledTime: string;
    durationMinutes: number;
    content: string;
  }) => {
    setEditingNote(null);
    setPrefillSchedule(slot);
    setIsModalOpen(true);
  };

  return (
    <div className="min-h-screen flex bg-slate-50 text-slate-900">
      <Sidebar
        activeView={activeView}
        onSelectView={setActiveView}
        notes={notes}
        goals={weeklyGoals}
        isOpenMobile={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
      />

      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Bar Contract: 3 clean zones (Breadcrumb / Quick nav links / Primary CTA) */}
        <header className="sticky top-0 z-30 flex items-center justify-between gap-8 px-6 py-3.5 bg-white border-b border-slate-200">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              className="lg:hidden rounded-md p-2 text-slate-600 hover:bg-slate-100 hover:text-slate-900"
              aria-label="Mở menu điều hướng"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="text-sm font-medium text-slate-500 whitespace-nowrap truncate">
              <span>Không gian học tập</span>
              <span className="mx-2 text-slate-300" aria-hidden="true">
                /
              </span>
              <span className="font-semibold text-slate-900">
                {VIEW_LABELS[activeView]}
              </span>
            </div>
          </div>

          <nav
            className="hidden md:flex items-center gap-6 text-sm font-medium"
            aria-label="Chuyển nhanh phân hệ"
          >
            <button
              type="button"
              onClick={() => setActiveView('notes')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${
                activeView === 'notes'
                  ? 'text-blue-700 border-b-2 border-blue-600'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Ghi chú
            </button>
            <button
              type="button"
              onClick={() => setActiveView('schedule')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${
                activeView === 'schedule'
                  ? 'text-blue-700 border-b-2 border-blue-600'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Lịch ngày
            </button>
            <button
              type="button"
              onClick={() => setActiveView('ai_coach')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${
                activeView === 'ai_coach'
                  ? 'text-blue-700 border-b-2 border-blue-600'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              AI Gợi ý
            </button>
            <button
              type="button"
              onClick={() => setActiveView('goals_guide')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${
                activeView === 'goals_guide'
                  ? 'text-blue-700 border-b-2 border-blue-600'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Mục tiêu tuần
            </button>
            <button
              type="button"
              onClick={() => setActiveView('python_source')}
              className={`whitespace-nowrap shrink-0 pb-0.5 transition-colors ${
                activeView === 'python_source'
                  ? 'text-blue-700 border-b-2 border-blue-600'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Python Flask
            </button>
          </nav>

          <div className="shrink-0">
            <button
              type="button"
              onClick={() => {
                setEditingNote(null);
                setPrefillSchedule(null);
                setIsModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 rounded-md bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 transition-colors whitespace-nowrap shrink-0"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>Thêm ghi chú</span>
            </button>
          </div>
        </header>

        <main className="flex-1 p-5 sm:p-6 lg:p-8 max-w-[1360px] w-full mx-auto">
          {activeView === 'notes' && (
            <NotesWorkspace
              notes={notes}
              goals={weeklyGoals}
              onToggleComplete={handleToggleComplete}
              onDeleteNote={handleDeleteNote}
              onMoveNote={handleMoveNote}
              onOpenCreate={() => {
                setEditingNote(null);
                setPrefillSchedule(null);
                setIsModalOpen(true);
              }}
              onOpenEdit={(note) => {
                setPrefillSchedule(null);
                setEditingNote(note);
                setIsModalOpen(true);
              }}
              onResetSeedData={handleResetSeedData}
            />
          )}

          {activeView === 'schedule' && (
            <DailyScheduleView
              blocks={dailySchedule}
              onAddBlock={handleAddScheduleBlock}
              onUpdateStatus={handleUpdateScheduleStatus}
              onDeleteBlock={handleDeleteScheduleBlock}
              onNavigateToAI={() => setActiveView('ai_coach')}
            />
          )}

          {activeView === 'ai_coach' && (
            <AICoachView
              notes={notes}
              dailySchedule={dailySchedule}
              weeklyGoals={weeklyGoals}
              cachedAIResult={cachedAIResult}
              onSaveAIResult={handleSaveAIResult}
              onApplySlotAsNote={handleApplySlotAsNote}
            />
          )}

          {activeView === 'goals_guide' && (
            <WeeklyGoalsAndGuideView
              goals={weeklyGoals}
              notes={notes}
              onAddGoal={handleAddGoal}
              onAdjustGoalProgress={handleAdjustGoalProgress}
              onDeleteGoal={handleDeleteGoal}
            />
          )}

          {activeView === 'python_source' && <PythonSourceView />}
        </main>
      </div>

      <NoteFormModal
        isOpen={isModalOpen}
        editingNote={editingNote}
        goals={weeklyGoals}
        prefillSchedule={prefillSchedule}
        onClose={() => {
          setIsModalOpen(false);
          setEditingNote(null);
          setPrefillSchedule(null);
        }}
        onSave={handleSaveNote}
      />

      {toastMsg && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-5 right-5 z-50 rounded-md bg-slate-900 px-4 py-2.5 text-xs font-medium text-white shadow-lg"
        >
          {toastMsg}
        </div>
      )}
    </div>
  );
}
