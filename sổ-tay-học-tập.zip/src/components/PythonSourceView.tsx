import { useEffect, useState } from 'react';
import { Check, Code2, Copy, Download } from 'lucide-react';

interface PythonFileItem {
  path: string;
  filename: string;
  content: string;
}

export function PythonSourceView() {
  const [files, setFiles] = useState<PythonFileItem[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>('python_app/app.py');
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    let active = true;
    fetch('/api/python-files')
      .then(async (res) => {
        const data = (await res.json()) as { files?: PythonFileItem[]; error?: string };
        if (!res.ok) throw new Error(data.error || 'Không thể tải mã nguồn Python');
        return data.files || [];
      })
      .then((list) => {
        if (!active) return;
        setFiles(list);
        if (list.length > 0) setSelectedPath(list[0].path);
      })
      .catch((err: unknown) => {
        if (!active) return;
        setErrorMsg(err instanceof Error ? err.message : 'Lỗi tải dữ liệu');
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);

  const currentFile = files.find((f) => f.path === selectedPath) || files[0];

  const handleCopy = async () => {
    if (!currentFile) return;
    await navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = (file: PythonFileItem) => {
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <div className="border-b border-slate-200 pb-5">
        <h1 className="font-display text-2xl font-bold text-slate-900">
          Mã nguồn Python Web (Flask)
        </h1>
        <p className="mt-1 text-sm text-slate-600 max-w-3xl">
          Toàn bộ dự án Python Flask hoàn chỉnh đã được tạo sẵn trong thư mục <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">python_app/</code>. Bạn có thể xem, sao chép hoặc tải từng tệp về máy để chạy trực tiếp bằng Python 3.
        </p>
      </div>

      <div className="rounded-lg border border-slate-200 bg-white p-5 space-y-2 text-sm text-slate-700">
        <p className="font-semibold text-slate-900">Lệnh chạy phiên bản Python trên máy cá nhân:</p>
        <pre className="rounded-md bg-slate-900 text-slate-100 p-3.5 text-xs font-mono overflow-x-auto">
{`cd python_app
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
export GEMINI_API_KEY="your_api_key"
python app.py`}
        </pre>
      </div>

      {errorMsg && (
        <div className="rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
          {errorMsg}
        </div>
      )}

      {loading ? (
        <div className="rounded-lg border border-slate-200 bg-white p-8 text-sm text-slate-500">
          Đang tải các tệp mã nguồn Python...
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-4 rounded-lg border border-slate-200 bg-white divide-y divide-slate-200 overflow-hidden">
            <div className="px-4 py-3 bg-slate-50/70 text-xs font-semibold text-slate-700">
              Cấu trúc dự án python_app ({files.length} tệp)
            </div>
            {files.map((file) => {
              const active = file.path === currentFile?.path;
              return (
                <div
                  key={file.path}
                  className={`flex items-center justify-between px-4 py-3 text-xs ${
                    active ? 'bg-blue-50 text-blue-800 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedPath(file.path)}
                    className="flex items-center gap-2 text-left min-w-0 flex-1 font-mono truncate"
                  >
                    <Code2 className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    <span className="truncate">{file.path}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDownload(file)}
                    className="p-1 text-slate-400 hover:text-slate-900 shrink-0"
                    aria-label={`Tải tệp ${file.filename}`}
                  >
                    <Download className="h-3.5 w-3.5" />
                  </button>
                </div>
              );
            })}
          </div>

          <div className="lg:col-span-8 rounded-lg border border-slate-200 bg-white overflow-hidden">
            {currentFile && (
              <>
                <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200 bg-slate-50/70">
                  <span className="font-mono text-xs font-semibold text-slate-900">
                    {currentFile.path}
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={handleCopy}
                      className="inline-flex items-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
                    >
                      {copied ? (
                        <>
                          <Check className="h-3.5 w-3.5 text-emerald-600" />
                          <span>Đã sao chép</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3.5 w-3.5" />
                          <span>Sao chép</span>
                        </>
                      )}
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDownload(currentFile)}
                      className="inline-flex items-center gap-1.5 rounded-md bg-slate-900 px-3 py-1.5 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Tải tệp</span>
                    </button>
                  </div>
                </div>
                <pre className="p-4 text-xs font-mono text-slate-800 bg-slate-50 overflow-x-auto max-h-[600px] leading-relaxed">
                  {currentFile.content}
                </pre>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
