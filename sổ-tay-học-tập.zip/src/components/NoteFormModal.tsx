import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { X } from 'lucide-react';
import type {
  NoteCategory,
  NoteItem,
  NotePriority,
  WeeklyGoal,
} from '../types/notes';
import { getTodayISO } from '../utils/storage';

interface NoteFormModalProps {
  isOpen: boolean;
  editingNote: NoteItem | null;
  goals: WeeklyGoal[];
  prefillSchedule?: {
    title?: string;
    scheduledDate?: string;
    scheduledTime?: string;
    durationMinutes?: number;
    content?: string;
  } | null;
  onClose: () => void;
  onSave: (
    data: Omit<NoteItem, 'id' | 'createdAt' | 'updatedAt' | 'orderIndex'>,
    existingId?: string
  ) => void;
}

const CATEGORIES: NoteCategory[] = [
  'Học tập',
  'Lịch nhắc',
  'Dự án',
  'Ôn tập',
  'Cá nhân',
];

const PRIORITIES: NotePriority[] = ['Cao', 'Trung bình', 'Thấp'];

export function NoteFormModal({
  isOpen,
  editingNote,
  goals,
  prefillSchedule,
  onClose,
  onSave,
}: NoteFormModalProps) {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const [category, setCategory] = useState<NoteCategory>('Học tập');
  const [priority, setPriority] = useState<NotePriority>('Trung bình');
  const [scheduledDate, setScheduledDate] = useState(getTodayISO());
  const [scheduledTime, setScheduledTime] = useState('19:30');
  const [durationMinutes, setDurationMinutes] = useState(60);
  const [reminderEnabled, setReminderEnabled] = useState(true);
  const [completed, setCompleted] = useState(false);
  const [goalId, setGoalId] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    setErrorMsg('');

    if (editingNote) {
      setTitle(editingNote.title);
      setContent(editingNote.content);
      setCategory(editingNote.category);
      setPriority(editingNote.priority);
      setScheduledDate(editingNote.scheduledDate);
      setScheduledTime(editingNote.scheduledTime);
      setDurationMinutes(editingNote.durationMinutes);
      setReminderEnabled(editingNote.reminderEnabled);
      setCompleted(editingNote.completed);
      setGoalId(editingNote.goalId || '');
    } else if (prefillSchedule) {
      setTitle(prefillSchedule.title || '');
      setContent(prefillSchedule.content || '');
      setCategory('Lịch nhắc');
      setPriority('Cao');
      setScheduledDate(prefillSchedule.scheduledDate || getTodayISO());
      setScheduledTime(prefillSchedule.scheduledTime || '19:30');
      setDurationMinutes(prefillSchedule.durationMinutes || 60);
      setReminderEnabled(true);
      setCompleted(false);
      setGoalId(goals[0]?.id || '');
    } else {
      setTitle('');
      setContent('');
      setCategory('Học tập');
      setPriority('Trung bình');
      setScheduledDate(getTodayISO());
      setScheduledTime('19:30');
      setDurationMinutes(60);
      setReminderEnabled(true);
      setCompleted(false);
      setGoalId('');
    }
  }, [isOpen, editingNote, prefillSchedule, goals]);

  if (!isOpen) return null;

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Vui lòng nhập tiêu đề ghi chú.');
      return;
    }
    if (!content.trim()) {
      setErrorMsg('Vui lòng nhập nội dung chi tiết cho ghi chú.');
      return;
    }
    if (!scheduledDate) {
      setErrorMsg('Vui lòng chọn ngày áp dụng / lịch nhắc.');
      return;
    }

    onSave(
      {
        title: title.trim(),
        content: content.trim(),
        category,
        priority,
        scheduledDate,
        scheduledTime: scheduledTime || '19:30',
        durationMinutes: Math.max(15, Math.min(360, Number(durationMinutes) || 60)),
        reminderEnabled,
        completed,
        goalId: goalId || undefined,
      },
      editingNote?.id
    );
    onClose();
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="note-modal-title"
    >
      <div className="w-full max-w-xl rounded-lg border border-slate-200 bg-white shadow-xl max-h-[92vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
          <h2
            id="note-modal-title"
            className="font-display text-lg font-semibold text-slate-900"
          >
            {editingNote ? 'Chỉnh sửa ghi chú' : 'Thêm ghi chú & Lịch học mới'}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
            aria-label="Đóng hộp thoại"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="overflow-y-auto px-6 py-5 space-y-4">
          {errorMsg && (
            <div className="rounded-md border border-red-200 bg-red-50 px-3.5 py-2.5 text-sm text-red-700">
              {errorMsg}
            </div>
          )}

          <div>
            <label
              htmlFor="note-title"
              className="block text-sm font-medium text-slate-700 mb-1.5"
            >
              Tiêu đề ghi chú
            </label>
            <input
              id="note-title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Ví dụ: Ôn tập FastAPI & viết API CRUD"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>

          <div>
            <label
              htmlFor="note-content"
              className="block text-sm font-medium text-slate-700 mb-1.5"
            >
              Nội dung ghi chú (có thể ghi khung giờ trống như "rảnh 19:30 - 21:00" để AI phân tích)
            </label>
            <textarea
              id="note-content"
              rows={4}
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Nhập nội dung cần học, đầu việc chi tiết và khoảng thời gian trống bạn có trong ngày..."
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label
                htmlFor="note-category"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Phân loại
              </label>
              <select
                id="note-category"
                value={category}
                onChange={(e) => setCategory(e.target.value as NoteCategory)}
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label
                htmlFor="note-priority"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Mức độ ưu tiên
              </label>
              <select
                id="note-priority"
                value={priority}
                onChange={(e) => setPriority(e.target.value as NotePriority)}
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              >
                {PRIORITIES.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label
                htmlFor="note-date"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Ngày áp dụng
              </label>
              <input
                id="note-date"
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              />
            </div>

            <div>
              <label
                htmlFor="note-time"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Giờ nhắc học
              </label>
              <input
                id="note-time"
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e.target.value)}
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              />
            </div>

            <div>
              <label
                htmlFor="note-duration"
                className="block text-sm font-medium text-slate-700 mb-1.5"
              >
                Thời lượng (phút)
              </label>
              <input
                id="note-duration"
                type="number"
                min={15}
                max={360}
                step={15}
                value={durationMinutes}
                onChange={(e) => setDurationMinutes(Number(e.target.value))}
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="note-goal"
              className="block text-sm font-medium text-slate-700 mb-1.5"
            >
              Liên kết mục tiêu tuần (tùy chọn)
            </label>
            <select
              id="note-goal"
              value={goalId}
              onChange={(e) => setGoalId(e.target.value)}
              className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            >
              <option value="">Không liên kết mục tiêu cụ thể</option>
              {goals.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.title}
                </option>
              ))}
            </select>
          </div>

          <div className="flex flex-wrap items-center gap-6 pt-1">
            <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={reminderEnabled}
                onChange={(e) => setReminderEnabled(e.target.checked)}
                className="h-4 w-4 rounded border-slate-300 text-blue-600 focus:ring-blue-600"
              />
              <span>Bật lịch nhắc việc học tập</span>
            </label>

            {editingNote && (
              <label className="inline-flex items-center gap-2 text-sm text-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={completed}
                  onChange={(e) => setCompleted(e.target.checked)}
                  className="h-4 w-4 rounded border-slate-300 text-emerald-600 focus:ring-emerald-600"
                />
                <span>Đã hoàn thành ghi chú này</span>
              </label>
            )}
          </div>

          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-200">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-md border border-slate-300 bg-white text-sm font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
            >
              Hủy bỏ
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-md bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 whitespace-nowrap"
            >
              {editingNote ? 'Lưu thay đổi' : 'Lưu vào LocalStorage'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
