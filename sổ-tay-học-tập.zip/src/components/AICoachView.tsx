import { useMemo, useState } from 'react';
import {
  AlertCircle,
  Bot,
  CalendarPlus,
  CheckCircle2,
  Clock,
  Cpu,
  RefreshCw,
} from 'lucide-react';
import type {
  AIStudyCoachResult,
  DailyScheduleBlock,
  NoteItem,
  WeeklyGoal,
} from '../types/notes';
import {
  analyzeStudyScheduleWithJS,
  computeGoalProgress,
  computeOverallWeeklyProgress,
} from '../utils/studyAnalyzer';
import { getTodayISO } from '../utils/storage';

interface AICoachViewProps {
  notes: NoteItem[];
  dailySchedule: DailyScheduleBlock[];
  weeklyGoals: WeeklyGoal[];
  cachedAIResult: AIStudyCoachResult | null;
  onSaveAIResult: (result: AIStudyCoachResult) => void;
  onApplySlotAsNote: (slot: {
    title: string;
    scheduledDate: string;
    scheduledTime: string;
    durationMinutes: number;
    content: string;
  }) => void;
}

export function AICoachView({
  notes,
  dailySchedule,
  weeklyGoals,
  cachedAIResult,
  onSaveAIResult,
  onApplySlotAsNote,
}: AICoachViewProps) {
  const [customPrompt, setCustomPrompt] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Client-side JavaScript analysis of free time intervals written in notes + schedule
  const jsAnalysis = useMemo(
    () => analyzeStudyScheduleWithJS(notes, dailySchedule),
    [notes, dailySchedule]
  );

  const overallGoalPercent = useMemo(
    () => computeOverallWeeklyProgress(weeklyGoals),
    [weeklyGoals]
  );

  const handleRunGeminiAnalysis = async () => {
    setIsLoading(true);
    setErrorMsg('');
    try {
      const response = await fetch('/api/ai/study-coach', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          notes,
          dailySchedule,
          weeklyGoals,
          customPrompt,
          currentDate: getTodayISO(),
        }),
      });

      const data = (await response.json()) as AIStudyCoachResult & {
        error?: string;
      };

      if (!response.ok) {
        throw new Error(
          data.error || `Máy chủ trả về mã lỗi ${response.status}`
        );
      }

      onSaveAIResult({
        ...data,
        generatedAt: new Date().toLocaleTimeString('vi-VN', {
          hour: '2-digit',
          minute: '2-digit',
        }),
      });
    } catch (err: unknown) {
      const msg =
        err instanceof Error
          ? err.message
          : 'Không thể hoàn tất phân tích Gemini AI.';
      setErrorMsg(msg);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Trợ lý AI Quản lý Học tập & Mục tiêu Tuần
          </h1>
          <p className="mt-1 text-sm text-slate-600 max-w-3xl">
            Hệ thống tự động trích xuất các khoảng thời gian trống từ ghi chú cá nhân bằng JavaScript để đề xuất 3 khung giờ học trong ngày, kết hợp phân tích chuyên sâu qua Gemini AI và theo dõi thanh tiến độ mục tiêu tuần.
          </p>
        </div>
      </div>

      {/* Section 1: Weekly Goal Progress Bars */}
      <div className="rounded-lg border border-slate-200 bg-white p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-4">
          <div>
            <h2 className="font-display text-base font-semibold text-slate-900">
              Tỷ lệ hoàn thành mục tiêu hàng tuần
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Cập nhật trực tiếp theo tiến độ từng mục tiêu tuần của bạn
            </p>
          </div>
          <div className="text-left sm:text-right">
            <span className="text-xs text-slate-500 block">Tổng tiến độ tuần</span>
            <span className="font-display text-xl font-bold text-blue-700 tabular-nums">
              {overallGoalPercent}%
            </span>
          </div>
        </div>

        {/* Overall progress bar */}
        <div className="space-y-1.5">
          <div
            className="h-3 w-full overflow-hidden rounded-full bg-slate-100"
            role="progressbar"
            aria-valuenow={overallGoalPercent}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Tổng tiến độ hoàn thành mục tiêu hàng tuần"
          >
            <div
              className="h-full bg-blue-600 transition-all duration-300"
              style={{ width: `${overallGoalPercent}%` }}
            />
          </div>
        </div>

        {/* Individual goal progress bars */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-4 pt-2">
          {weeklyGoals.map((goal) => {
            const { percent, statusLabel } = computeGoalProgress(goal);
            const barColor =
              percent >= 100
                ? 'bg-emerald-600'
                : percent >= 55
                  ? 'bg-blue-600'
                  : 'bg-amber-600';
            const statusTextColor =
              percent >= 100
                ? 'text-emerald-700'
                : percent >= 55
                  ? 'text-blue-700'
                  : 'text-amber-700';

            return (
              <div key={goal.id} className="space-y-2">
                <div className="flex items-start justify-between gap-3 text-sm">
                  <div className="min-w-0">
                    <p className="font-medium text-slate-900 truncate">
                      {goal.title}
                    </p>
                    <p className="text-xs text-slate-500 tabular-nums mt-0.5">
                      {goal.completedCount}/{goal.targetCount} {goal.unit} ·{' '}
                      <span className={`font-medium ${statusTextColor}`}>
                        {statusLabel}
                      </span>
                    </p>
                  </div>
                  <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums shrink-0">
                    {percent}%
                  </span>
                </div>
                <div
                  className="h-2 w-full overflow-hidden rounded-full bg-slate-100"
                  role="progressbar"
                  aria-valuenow={percent}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={goal.title}
                >
                  <div
                    className={`h-full transition-all duration-300 ${barColor}`}
                    style={{ width: `${percent}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Section 2: JavaScript Local Analyzer (3 Daily Slots from Notes Free Time) */}
      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <Cpu className="h-4 w-4 text-blue-600 shrink-0" aria-hidden="true" />
            <h2 className="font-display text-base font-semibold text-slate-900">
              Phân tích ghi chú bằng JavaScript — 3 khung giờ học tập trong ngày
            </h2>
          </div>
          <span className="text-xs font-mono text-slate-500 tabular-nums">
            Phát hiện {jsAnalysis.extractedFromNotes.length} khoảng trống trong ghi chú
          </span>
        </div>

        <div className="p-6 space-y-5">
          <p className="text-sm text-slate-700 leading-relaxed">
            {jsAnalysis.summaryText}
          </p>

          {jsAnalysis.extractedFromNotes.length > 0 && (
            <div className="text-xs text-slate-600 space-y-1.5 border-t border-slate-100 pt-4">
              <p className="font-semibold text-slate-800">
                Các khoảng thời gian trống trích xuất trực tiếp từ nội dung ghi chú:
              </p>
              <div className="flex flex-wrap gap-x-4 gap-y-1.5 tabular-nums">
                {jsAnalysis.extractedFromNotes.map((w, i) => (
                  <span key={`${w.sourceNoteId}-${i}`} className="text-slate-700">
                    <span className="font-mono font-semibold text-slate-900">
                      {w.startTime}–{w.endTime}
                    </span>{' '}
                    ({w.periodLabel} · từ "{w.sourceNoteTitle}")
                  </span>
                ))}
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
            {jsAnalysis.suggestedSlots.map((slot) => (
              <div
                key={slot.slotOrder}
                className="rounded-md border border-slate-200 bg-slate-50/50 p-4 flex flex-col justify-between gap-4"
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between gap-2 text-xs text-slate-500">
                    <span className="font-semibold text-blue-700">
                      Khung giờ #{slot.slotOrder} · {slot.periodLabel}
                    </span>
                    <span className="font-mono tabular-nums">
                      {slot.durationMinutes} phút
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 font-mono text-lg font-bold text-slate-900 tabular-nums">
                    <Clock className="h-4 w-4 text-slate-400" aria-hidden="true" />
                    <span>{slot.timeRange}</span>
                  </div>

                  <p className="text-sm font-semibold text-slate-900 leading-snug">
                    {slot.recommendedTaskTitle}
                  </p>

                  <p className="text-xs text-slate-600 leading-relaxed">
                    {slot.scoreReason}
                  </p>
                  <p className="text-xs text-slate-500">{slot.sourceLabel}</p>
                </div>

                <button
                  type="button"
                  onClick={() =>
                    onApplySlotAsNote({
                      title: `Lịch học khung ${slot.periodLabel}: ${slot.recommendedTaskTitle}`,
                      scheduledDate: getTodayISO(),
                      scheduledTime: slot.startTime,
                      durationMinutes: Math.min(120, slot.durationMinutes),
                      content: `Áp dụng theo phân tích khung giờ trống ${slot.timeRange} (${slot.sourceLabel}).`,
                    })
                  }
                  className="inline-flex items-center justify-center gap-1.5 rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-800 hover:bg-slate-100 whitespace-nowrap"
                >
                  <CalendarPlus className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Đặt lịch nhắc giờ này</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Section 3: Gemini AI Deep Coach */}
      <div className="rounded-lg border border-slate-200 bg-white overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Bot className="h-4 w-4 text-blue-600 shrink-0" aria-hidden="true" />
            <div>
              <h2 className="font-display text-base font-semibold text-slate-900">
                Cố vấn AI Chuyên sâu (Gemini)
              </h2>
              <p className="text-xs text-slate-500">
                Phân tích ngữ cảnh ghi chú, thói quen hàng ngày và đề xuất chiến lược hoàn thành mục tiêu tuần
              </p>
            </div>
          </div>

          <button
            type="button"
            disabled={isLoading}
            onClick={handleRunGeminiAnalysis}
            className="inline-flex items-center justify-center gap-2 rounded-md bg-blue-600 px-4 py-2 text-sm font-medium text-white hover:bg-blue-700 disabled:opacity-60 whitespace-nowrap shrink-0"
          >
            <RefreshCw
              className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`}
              aria-hidden="true"
            />
            <span>
              {isLoading ? 'Đang phân tích...' : 'Phân tích với Gemini AI'}
            </span>
          </button>
        </div>

        <div className="p-6 space-y-5">
          <div>
            <label
              htmlFor="ai-custom-prompt"
              className="block text-xs font-medium text-slate-700 mb-1.5"
            >
              Ghi chú thêm cho AI (tùy chọn, ví dụ: "Tối thứ 5 mình bận họp nhóm 19h-21h, hãy xếp lại giờ ôn Python")
            </label>
            <input
              id="ai-custom-prompt"
              type="text"
              value={customPrompt}
              onChange={(e) => setCustomPrompt(e.target.value)}
              placeholder="Nhập ràng buộc hoặc ưu tiên học tập hôm nay..."
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>

          {errorMsg && (
            <div className="flex items-start gap-2.5 rounded-md border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
              <AlertCircle className="h-4 w-4 mt-0.5 shrink-0" aria-hidden="true" />
              <span>{errorMsg}</span>
            </div>
          )}

          {isLoading && (
            <div className="space-y-3 py-4 animate-pulse">
              <div className="h-4 w-3/4 rounded bg-slate-200" />
              <div className="h-4 w-1/2 rounded bg-slate-200" />
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                <div className="h-32 rounded bg-slate-100" />
                <div className="h-32 rounded bg-slate-100" />
                <div className="h-32 rounded bg-slate-100" />
              </div>
            </div>
          )}

          {!isLoading && !cachedAIResult && !errorMsg && (
            <div className="rounded-md border border-dashed border-slate-300 p-8 text-center space-y-2">
              <p className="text-sm font-medium text-slate-800">
                Chưa có bản phân tích Gemini AI cho dữ liệu hiện tại
              </p>
              <p className="text-xs text-slate-500">
                Nhấn nút "Phân tích với Gemini AI" ở trên để AI đọc toàn bộ ghi chú, lịch trình và đưa ra kế hoạch học tập cá nhân hóa.
              </p>
            </div>
          )}

          {!isLoading && cachedAIResult && (
            <div className="space-y-6">
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <h3 className="text-sm font-semibold text-slate-900">
                    Đánh giá tổng quan từ Gemini AI
                  </h3>
                  {cachedAIResult.generatedAt && (
                    <span className="text-xs font-mono text-slate-500 tabular-nums">
                      Cập nhật lúc {cachedAIResult.generatedAt}
                    </span>
                  )}
                </div>
                <p className="text-sm text-slate-700 leading-relaxed">
                  {cachedAIResult.overallAssessment}
                </p>
              </div>

              {cachedAIResult.extractedFreeWindows?.length > 0 && (
                <div className="text-xs text-slate-600 space-y-1">
                  <p className="font-semibold text-slate-800">
                    Khoảng thời gian trống AI ghi nhận:
                  </p>
                  <p>{cachedAIResult.extractedFreeWindows.join(' · ')}</p>
                </div>
              )}

              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-slate-900">
                  3 khung giờ học hiệu quả AI đề xuất
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {cachedAIResult.suggestedSlots.slice(0, 3).map((slot, idx) => (
                    <div
                      key={`${slot.startTime}-${idx}`}
                      className="rounded-md border border-slate-200 bg-white p-4 flex flex-col justify-between gap-4"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs text-slate-500">
                          <span className="font-semibold text-blue-700">
                            {slot.dayLabel}
                          </span>
                          <span className="font-mono tabular-nums">
                            {slot.durationMinutes} phút
                          </span>
                        </div>
                        <p className="font-mono text-base font-bold text-slate-900 tabular-nums">
                          {slot.timeRange}
                        </p>
                        <p className="text-sm font-semibold text-slate-900">
                          {slot.focusTopic}
                        </p>
                        {slot.linkedNoteTitle && (
                          <p className="text-xs text-slate-500">
                            Liên quan: {slot.linkedNoteTitle}
                          </p>
                        )}
                        <p className="text-xs text-slate-600 leading-relaxed">
                          {slot.reason}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          onApplySlotAsNote({
                            title: slot.focusTopic,
                            scheduledDate: slot.recommendedDate || getTodayISO(),
                            scheduledTime: slot.startTime || '19:30',
                            durationMinutes: slot.durationMinutes || 60,
                            content: `${slot.reason}${slot.linkedNoteTitle ? ` (Gắn với: ${slot.linkedNoteTitle})` : ''}`,
                          })
                        }
                        className="inline-flex items-center justify-center gap-1.5 rounded-md bg-slate-900 px-3 py-2 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap"
                      >
                        <CalendarPlus className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Áp dụng vào ghi chú</span>
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {cachedAIResult.weeklyGoalAnalysis?.length > 0 && (
                <div className="space-y-3 pt-2 border-t border-slate-200">
                  <h3 className="text-sm font-semibold text-slate-900">
                    Nhận xét tiến độ từng mục tiêu tuần
                  </h3>
                  <div className="divide-y divide-slate-200 rounded-md border border-slate-200">
                    {cachedAIResult.weeklyGoalAnalysis.map((ga, idx) => (
                      <div
                        key={idx}
                        className="px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-sm"
                      >
                        <div className="space-y-0.5">
                          <p className="font-medium text-slate-900">
                            {ga.goalTitle}
                          </p>
                          <p className="text-xs text-slate-600">
                            {ga.actionableTip}
                          </p>
                        </div>
                        <div className="flex items-center gap-3 shrink-0 text-xs tabular-nums">
                          <span className="font-medium text-slate-700">
                            {ga.status}
                          </span>
                          <span className="font-mono font-semibold text-blue-700">
                            {ga.completionPercent}%
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {cachedAIResult.scheduleTip && (
                <div className="flex items-start gap-2.5 rounded-md border border-slate-200 bg-slate-50 px-4 py-3 text-xs text-slate-700">
                  <CheckCircle2
                    className="h-4 w-4 text-emerald-600 mt-0.5 shrink-0"
                    aria-hidden="true"
                  />
                  <span>{cachedAIResult.scheduleTip}</span>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
