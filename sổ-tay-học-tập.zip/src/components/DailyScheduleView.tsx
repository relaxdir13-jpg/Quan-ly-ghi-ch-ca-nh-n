import { useState } from 'react';
import type { FormEvent } from 'react';
import { Clock, Plus, Trash2 } from 'lucide-react';
import type { DailyScheduleBlock, ScheduleBlockStatus } from '../types/notes';

interface DailyScheduleViewProps {
  blocks: DailyScheduleBlock[];
  onAddBlock: (block: Omit<DailyScheduleBlock, 'id'>) => void;
  onUpdateStatus: (id: string, status: ScheduleBlockStatus) => void;
  onDeleteBlock: (id: string) => void;
  onNavigateToAI: () => void;
}

const STATUS_OPTIONS: ScheduleBlockStatus[] = [
  'Rảnh - Có thể học',
  'Bận',
  'Nghỉ ngơi',
];

export function DailyScheduleView({
  blocks,
  onAddBlock,
  onUpdateStatus,
  onDeleteBlock,
  onNavigateToAI,
}: DailyScheduleViewProps) {
  const [startTime, setStartTime] = useState('18:00');
  const [endTime, setEndTime] = useState('19:00');
  const [label, setLabel] = useState('');
  const [status, setStatus] = useState<ScheduleBlockStatus>('Rảnh - Có thể học');
  const [errorMsg, setErrorMsg] = useState('');

  const sortedBlocks = [...blocks].sort((a, b) =>
    a.startTime.localeCompare(b.startTime)
  );

  const freeCount = sortedBlocks.filter(
    (b) => b.status === 'Rảnh - Có thể học'
  ).length;

  const handleCreate = (e: FormEvent) => {
    e.preventDefault();
    if (!label.trim()) {
      setErrorMsg('Vui lòng nhập mô tả hoạt động trong khung giờ này.');
      return;
    }
    if (startTime >= endTime) {
      setErrorMsg('Giờ kết thúc phải lớn hơn giờ bắt đầu.');
      return;
    }
    setErrorMsg('');
    onAddBlock({
      startTime,
      endTime,
      label: label.trim(),
      status,
    });
    setLabel('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Lịch trình hàng ngày
          </h1>
          <p className="mt-1 text-sm text-slate-600 max-w-2xl">
            Thiết lập các khung giờ bận, nghỉ ngơi và khung giờ trống trong ngày. Trợ lý AI sẽ kết hợp lịch trình này với các khoảng thời gian trống trong ghi chú để đề xuất giờ học tối ưu.
          </p>
        </div>
        <button
          type="button"
          onClick={onNavigateToAI}
          className="px-4 py-2 rounded-md bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 whitespace-nowrap shrink-0 self-start sm:self-auto"
        >
          Phân tích & Gợi ý giờ học
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-8 rounded-lg border border-slate-200 bg-white overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50/70">
            <span className="text-sm font-semibold text-slate-900">
              Khung thời gian trong ngày ({sortedBlocks.length} khung)
            </span>
            <span className="text-xs font-medium text-emerald-700 tabular-nums">
              {freeCount} khung rảnh có thể học
            </span>
          </div>

          {sortedBlocks.length === 0 ? (
            <div className="p-8 text-center text-sm text-slate-500">
              Chưa có khung giờ nào trong lịch trình. Hãy thêm khung giờ đầu tiên ở biểu mẫu bên cạnh.
            </div>
          ) : (
            <div className="divide-y divide-slate-200">
              {sortedBlocks.map((blk) => {
                const statusColor =
                  blk.status === 'Rảnh - Có thể học'
                    ? 'text-emerald-700'
                    : blk.status === 'Bận'
                      ? 'text-red-700'
                      : 'text-amber-700';

                return (
                  <div
                    key={blk.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 px-5 py-3.5 hover:bg-slate-50/70 transition-colors"
                  >
                    <div className="flex items-start sm:items-center gap-4 min-w-0">
                      <div className="flex items-center gap-1.5 font-mono text-sm font-medium text-slate-900 tabular-nums shrink-0">
                        <Clock className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
                        <span>
                          {blk.startTime} – {blk.endTime}
                        </span>
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-slate-900 truncate">
                          {blk.label}
                        </p>
                        <p className={`text-xs font-medium mt-0.5 ${statusColor}`}>
                          {blk.status}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <select
                        value={blk.status}
                        onChange={(e) =>
                          onUpdateStatus(
                            blk.id,
                            e.target.value as ScheduleBlockStatus
                          )
                        }
                        aria-label={`Trạng thái cho ${blk.label}`}
                        className="rounded-md border border-slate-300 bg-white px-2.5 py-1.5 text-xs font-medium text-slate-700 focus:border-blue-600 focus:outline-none"
                      >
                        {STATUS_OPTIONS.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => onDeleteBlock(blk.id)}
                        className="rounded-md p-2 text-slate-400 hover:bg-red-50 hover:text-red-600 transition-colors"
                        aria-label={`Xóa khung giờ ${blk.startTime} - ${blk.endTime}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <form
          onSubmit={handleCreate}
          className="lg:col-span-4 rounded-lg border border-slate-200 bg-white p-5 space-y-4"
        >
          <h2 className="font-display text-base font-semibold text-slate-900">
            Thêm khung giờ hàng ngày
          </h2>

          {errorMsg && (
            <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
              {errorMsg}
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="blk-start"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Từ giờ
              </label>
              <input
                id="blk-start"
                type="time"
                value={startTime}
                onChange={(e) => setStartTime(e.target.value)}
                className="w-full rounded-md border border-slate-300 px-2.5 py-2 text-sm font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
            <div>
              <label
                htmlFor="blk-end"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Đến giờ
              </label>
              <input
                id="blk-end"
                type="time"
                value={endTime}
                onChange={(e) => setEndTime(e.target.value)}
                className="w-full rounded-md border border-slate-300 px-2.5 py-2 text-sm font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label
              htmlFor="blk-label"
              className="block text-xs font-medium text-slate-700 mb-1"
            >
              Hoạt động
            </label>
            <input
              id="blk-label"
              type="text"
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="Ví dụ: Học nhóm buổi chiều hoặc Tự học"
              className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
            />
          </div>

          <div>
            <label
              htmlFor="blk-status"
              className="block text-xs font-medium text-slate-700 mb-1"
            >
              Tính chất khung giờ
            </label>
            <select
              id="blk-status"
              value={status}
              onChange={(e) => setStatus(e.target.value as ScheduleBlockStatus)}
              className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none"
            >
              {STATUS_OPTIONS.map((opt) => (
                <option key={opt} value={opt}>
                  {opt}
                </option>
              ))}
            </select>
          </div>

          <button
            type="submit"
            className="w-full inline-flex items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap"
          >
            <Plus className="h-4 w-4" aria-hidden="true" />
            <span>Thêm vào lịch trình</span>
          </button>
        </form>
      </div>
    </div>
  );
}
