import { useState } from 'react';
import type { FormEvent } from 'react';
import { Minus, Plus, Trash2 } from 'lucide-react';
import type { NoteCategory, NoteItem, WeeklyGoal } from '../types/notes';
import {
  computeGoalProgress,
  computeOverallWeeklyProgress,
} from '../utils/studyAnalyzer';

interface WeeklyGoalsAndGuideViewProps {
  goals: WeeklyGoal[];
  notes: NoteItem[];
  onAddGoal: (goal: Omit<WeeklyGoal, 'id'>) => void;
  onAdjustGoalProgress: (id: string, delta: number) => void;
  onDeleteGoal: (id: string) => void;
}

const CATEGORIES: NoteCategory[] = [
  'Học tập',
  'Lịch nhắc',
  'Dự án',
  'Ôn tập',
  'Cá nhân',
];

export function WeeklyGoalsAndGuideView({
  goals,
  notes,
  onAddGoal,
  onAdjustGoalProgress,
  onDeleteGoal,
}: WeeklyGoalsAndGuideViewProps) {
  const [subTab, setSubTab] = useState<'goals' | 'guide'>('goals');
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<NoteCategory>('Học tập');
  const [targetCount, setTargetCount] = useState(5);
  const [unit, setUnit] = useState('buổi');
  const [errorMsg, setErrorMsg] = useState('');

  const overallPct = computeOverallWeeklyProgress(goals);

  const handleAddGoal = (e: FormEvent) => {
    e.preventDefault();
    if (!title.trim()) {
      setErrorMsg('Vui lòng nhập tên mục tiêu hàng tuần.');
      return;
    }
    setErrorMsg('');
    onAddGoal({
      title: title.trim(),
      category,
      targetCount: Math.max(1, Number(targetCount) || 1),
      completedCount: 0,
      unit: unit.trim() || 'buổi',
      weekRangeLabel: 'Tuần hiện tại',
    });
    setTitle('');
    setTargetCount(5);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-200 pb-5">
        <div>
          <h1 className="font-display text-2xl font-bold text-slate-900">
            Mục tiêu Hàng tuần & Hướng dẫn Vận hành
          </h1>
          <p className="mt-1 text-sm text-slate-600">
            Theo dõi tỷ lệ hoàn thành mục tiêu học tập bằng thanh tiến độ và xem tài liệu hướng dẫn kiến trúc a, b, c của ứng dụng.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-md self-start sm:self-auto">
          <button
            type="button"
            onClick={() => setSubTab('goals')}
            className={`px-3.5 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              subTab === 'goals'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Mục tiêu tuần ({goals.length})
          </button>
          <button
            type="button"
            onClick={() => setSubTab('guide')}
            className={`px-3.5 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-colors ${
              subTab === 'guide'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Hướng dẫn a, b, c
          </button>
        </div>
      </div>

      {subTab === 'goals' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <div className="lg:col-span-8 space-y-4">
            <div className="rounded-lg border border-slate-200 bg-white p-5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-slate-900">
                  Tổng tiến độ hoàn thành tuần này
                </span>
                <span className="font-mono text-lg font-bold text-blue-700 tabular-nums">
                  {overallPct}%
                </span>
              </div>
              <div
                className="h-3 w-full overflow-hidden rounded-full bg-slate-100"
                role="progressbar"
                aria-valuenow={overallPct}
                aria-valuemin={0}
                aria-valuemax={100}
              >
                <div
                  className="h-full bg-blue-600 transition-all duration-300"
                  style={{ width: `${overallPct}%` }}
                />
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-200 overflow-hidden">
              {goals.length === 0 ? (
                <div className="p-8 text-center text-sm text-slate-500">
                  Chưa có mục tiêu tuần nào. Hãy thêm mục tiêu mới ở biểu mẫu bên cạnh.
                </div>
              ) : (
                goals.map((goal) => {
                  const { percent, statusLabel } = computeGoalProgress(goal);
                  const linkedNotes = notes.filter((n) => n.goalId === goal.id);
                  const linkedDone = linkedNotes.filter((n) => n.completed).length;

                  const barColor =
                    percent >= 100
                      ? 'bg-emerald-600'
                      : percent >= 55
                        ? 'bg-blue-600'
                        : 'bg-amber-600';

                  return (
                    <div key={goal.id} className="p-5 space-y-3">
                      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                        <div className="space-y-1 min-w-0">
                          <h3 className="text-base font-semibold text-slate-900">
                            {goal.title}
                          </h3>
                          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 tabular-nums">
                            <span className="font-medium text-slate-700">
                              {goal.category}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>{goal.weekRangeLabel}</span>
                            <span aria-hidden="true">·</span>
                            <span>
                              {linkedDone}/{linkedNotes.length} ghi chú liên kết hoàn thành
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="font-medium text-slate-800">
                              {statusLabel}
                            </span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            type="button"
                            onClick={() => onAdjustGoalProgress(goal.id, -1)}
                            disabled={goal.completedCount <= 0}
                            aria-label={`Giảm tiến độ ${goal.title}`}
                            className="rounded-md border border-slate-300 p-1.5 text-slate-700 hover:bg-slate-100 disabled:opacity-40"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="font-mono text-sm font-semibold text-slate-900 tabular-nums min-w-[74px] text-center">
                            {goal.completedCount}/{goal.targetCount} {goal.unit}
                          </span>
                          <button
                            type="button"
                            onClick={() => onAdjustGoalProgress(goal.id, 1)}
                            aria-label={`Tăng tiến độ ${goal.title}`}
                            className="rounded-md border border-slate-300 p-1.5 text-slate-700 hover:bg-slate-100"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => onDeleteGoal(goal.id)}
                            aria-label={`Xóa mục tiêu ${goal.title}`}
                            className="rounded-md p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600 ml-1"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center gap-3">
                        <div
                          className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-100"
                          role="progressbar"
                          aria-valuenow={percent}
                          aria-valuemin={0}
                          aria-valuemax={100}
                        >
                          <div
                            className={`h-full transition-all duration-300 ${barColor}`}
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                        <span className="font-mono text-xs font-semibold text-slate-700 tabular-nums w-10 text-right">
                          {percent}%
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          <form
            onSubmit={handleAddGoal}
            className="lg:col-span-4 rounded-lg border border-slate-200 bg-white p-5 space-y-4"
          >
            <h2 className="font-display text-base font-semibold text-slate-900">
              Thêm mục tiêu tuần mới
            </h2>

            {errorMsg && (
              <div className="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                {errorMsg}
              </div>
            )}

            <div>
              <label
                htmlFor="goal-title"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Tên mục tiêu
              </label>
              <input
                id="goal-title"
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ví dụ: Hoàn thành 5 bài thực hành Python"
                className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none"
              />
            </div>

            <div>
              <label
                htmlFor="goal-cat"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Danh mục
              </label>
              <select
                id="goal-cat"
                value={category}
                onChange={(e) => setCategory(e.target.value as NoteCategory)}
                className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label
                  htmlFor="goal-target"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Chỉ tiêu
                </label>
                <input
                  id="goal-target"
                  type="number"
                  min={1}
                  max={500}
                  value={targetCount}
                  onChange={(e) => setTargetCount(Number(e.target.value))}
                  className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm font-mono text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>
              <div>
                <label
                  htmlFor="goal-unit"
                  className="block text-xs font-medium text-slate-700 mb-1"
                >
                  Đơn vị
                </label>
                <input
                  id="goal-unit"
                  type="text"
                  value={unit}
                  onChange={(e) => setUnit(e.target.value)}
                  placeholder="buổi / giờ / bài"
                  className="w-full rounded-md border border-slate-300 px-3 py-2 text-sm text-slate-900 focus:border-blue-600 focus:outline-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full inline-flex items-center justify-center gap-2 rounded-md bg-slate-900 px-4 py-2 text-sm font-medium text-white hover:bg-slate-800 whitespace-nowrap"
            >
              <Plus className="h-4 w-4" aria-hidden="true" />
              <span>Lưu mục tiêu tuần</span>
            </button>
          </form>
        </div>
      ) : (
        /* Documentation for a), b), c) */
        <div className="rounded-lg border border-slate-200 bg-white divide-y divide-slate-200">
          <section className="p-6 space-y-2.5">
            <h2 className="font-display text-lg font-bold text-slate-900">
              a) Giao diện chính
            </h2>
            <p className="text-sm text-slate-700 leading-relaxed">
              Giao diện chính được tổ chức theo bố cục 3 vùng rõ ràng: Thanh điều hướng bên trái (hiển thị 4 phân hệ chức năng và tóm tắt tiến độ tuần), thanh tiêu đề trên cùng (với nút tạo ghi chú nhanh) và vùng làm việc trung tâm. Ngay khi truy cập, ứng dụng nạp sẵn 12 ghi chú cá nhân có ý nghĩa trải dài trên 7 ngày (đáp ứng tối thiểu 10 ghi chú và 5 ngày áp dụng) kèm bảng thống kê số lượng, lịch nhắc sắp tới và trình đọc chi tiết ghi chú.
            </p>
          </section>

          <section className="p-6 space-y-3">
            <h2 className="font-display text-lg font-bold text-slate-900">
              b) Giao diện các chức năng chính
            </h2>
            <ul className="space-y-2 text-sm text-slate-700 list-disc pl-5 leading-relaxed">
              <li>
                <strong>Quản lý ghi chú (Thêm, Sửa, Xóa, Hiển thị):</strong> Hộp thoại thêm/sửa cho phép nhập tiêu đề, nội dung chi tiết, phân loại, mức độ ưu tiên, ngày áp dụng, giờ nhắc, thời lượng và liên kết mục tiêu tuần. Chế độ hiển thị hỗ trợ cả Danh sách chi tiết và Lịch học 5+ ngày.
              </li>
              <li>
                <strong>Sắp xếp thứ tự ghi chú:</strong> Hỗ trợ sắp xếp theo Thứ tự tùy chỉnh (nút di chuyển lên ↑ / xuống ↓ trực tiếp trên từng dòng), Lịch nhắc gần nhất/xa nhất, Mức độ ưu tiên, Trạng thái chưa xong trước, Tiêu đề A–Z và Thời gian cập nhật.
              </li>
              <li>
                <strong>Lịch trình hàng ngày:</strong> Giao diện thiết lập các khung giờ Bận, Nghỉ ngơi và Rảnh trong ngày để làm dữ liệu đầu vào cho AI.
              </li>
              <li>
                <strong>Trợ lý AI Quản lý Học tập & Thanh tiến độ:</strong> Kết hợp bộ phân tích JavaScript trích xuất trực tiếp khoảng thời gian trống từ văn bản ghi chú (gợi ý 3 khung giờ học tối ưu trong ngày) và Cố vấn Gemini AI, đi kèm các thanh tiến độ (progress bar) theo dõi tỷ lệ hoàn thành mục tiêu tuần.
              </li>
            </ul>
          </section>

          <section className="p-6 space-y-3">
            <h2 className="font-display text-lg font-bold text-slate-900">
              c) Cách vận hành các chức năng chính
            </h2>
            <ol className="space-y-2 text-sm text-slate-700 list-decimal pl-5 leading-relaxed">
              <li>
                <strong>Lưu trữ bền vững bằng LocalStorage:</strong> Mọi thao tác thêm, sửa, xóa, đánh dấu hoàn thành hoặc thay đổi thứ tự ghi chú, lịch trình và mục tiêu tuần đều được tuần tự hóa JSON và lưu ngay lập tức vào <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">window.localStorage</code>, đảm bảo dữ liệu không bị mất khi tải lại trang.
              </li>
              <li>
                <strong>Cách nhập thời gian trống để AI nhận diện:</strong> Khi viết nội dung ghi chú, bạn có thể ghi tự nhiên các khoảng trống như <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">19:30 - 21:30</code> hoặc <code className="font-mono text-xs bg-slate-100 px-1.5 py-0.5 rounded">từ 14h15 đến 16h00</code>. Bộ phân tích JavaScript sẽ tự động bóc tách các khung giờ này để chọn ra 3 khung giờ học tốt nhất trong ngày.
              </li>
              <li>
                <strong>Áp dụng gợi ý & Theo dõi tiến độ:</strong> Nhấn "Đặt lịch nhắc giờ này" hoặc "Áp dụng vào ghi chú" từ thẻ gợi ý của AI để chuyển thẳng khung giờ đề xuất thành ghi chú lịch nhắc mới, sau đó cập nhật tiến độ hoặc đánh dấu hoàn thành ghi chú để thanh tiến độ mục tiêu tuần tự động phản ánh tỷ lệ đạt được.
              </li>
            </ol>
          </section>
        </div>
      )}
    </div>
  );
}
