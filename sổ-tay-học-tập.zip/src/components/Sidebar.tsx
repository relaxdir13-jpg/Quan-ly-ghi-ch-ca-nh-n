import {
  BookOpen,
  Bot,
  CalendarClock,
  Code2,
  FileText,
  Target,
  X,
} from 'lucide-react';
import type { ActiveView, NoteItem, WeeklyGoal } from '../types/notes';
import { computeOverallWeeklyProgress } from '../utils/studyAnalyzer';
import { getSpanDaysCount } from '../utils/storage';

interface SidebarProps {
  activeView: ActiveView;
  onSelectView: (view: ActiveView) => void;
  notes: NoteItem[];
  goals: WeeklyGoal[];
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

const NAV_ITEMS: {
  id: ActiveView;
  label: string;
  icon: typeof FileText;
}[] = [
  { id: 'notes', label: 'Ghi chú & Lịch học', icon: FileText },
  { id: 'schedule', label: 'Lịch trình hàng ngày', icon: CalendarClock },
  { id: 'ai_coach', label: 'Trợ lý AI Lập lịch', icon: Bot },
  { id: 'goals_guide', label: 'Mục tiêu & Hướng dẫn', icon: Target },
  { id: 'python_source', label: 'Mã nguồn Python (Flask)', icon: Code2 },
];

export function Sidebar({
  activeView,
  onSelectView,
  notes,
  goals,
  isOpenMobile,
  onCloseMobile,
}: SidebarProps) {
  const completedNotes = notes.filter((n) => n.completed).length;
  const overallGoalPercent = computeOverallWeeklyProgress(goals);
  const spanDays = getSpanDaysCount(notes);

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between bg-white border-r border-slate-200 w-64">
      <div>
        <div className="flex items-center justify-between px-5 py-5 border-b border-slate-200">
          <div className="flex items-center gap-2.5 min-w-0">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-blue-600 text-white">
              <BookOpen className="h-4 w-4" aria-hidden="true" />
            </div>
            <span className="font-display text-base font-bold tracking-tight text-slate-900 whitespace-nowrap truncate">
              Sổ Tay Học Tập
            </span>
          </div>
          <button
            type="button"
            onClick={onCloseMobile}
            className="lg:hidden rounded-md p-1.5 text-slate-500 hover:bg-slate-100 hover:text-slate-900"
            aria-label="Đóng menu"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        <nav className="px-3 py-4 space-y-1" aria-label="Điều hướng chính">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onSelectView(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition-colors whitespace-nowrap ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    isActive ? 'text-blue-600' : 'text-slate-400'
                  }`}
                  aria-hidden="true"
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>

      <div className="p-4 border-t border-slate-200 space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-medium text-slate-700">Tiến độ mục tiêu tuần</span>
            <span className="font-mono font-semibold text-blue-700 tabular-nums">
              {overallGoalPercent}%
            </span>
          </div>
          <div
            className="h-2 w-full overflow-hidden rounded-full bg-slate-100"
            role="progressbar"
            aria-valuenow={overallGoalPercent}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Tỷ lệ hoàn thành mục tiêu tuần"
          >
            <div
              className="h-full bg-blue-600 transition-all duration-300"
              style={{ width: `${overallGoalPercent}%` }}
            />
          </div>
        </div>

        <div className="pt-2 border-t border-slate-100 space-y-1.5 text-xs text-slate-600">
          <div className="flex items-center justify-between">
            <span>Ghi chú đã xong</span>
            <span className="font-mono font-medium text-slate-900 tabular-nums">
              {completedNotes}/{notes.length}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Phạm vi lịch học</span>
            <span className="font-mono font-medium text-slate-900 tabular-nums">
              {spanDays} ngày
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span>Lưu trữ cục bộ</span>
            <span className="font-medium text-emerald-700">LocalStorage</span>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <aside className="hidden lg:block shrink-0">{sidebarContent}</aside>

      {isOpenMobile && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <div className="relative z-10 flex h-full">{sidebarContent}</div>
        </div>
      )}
    </>
  );
}
