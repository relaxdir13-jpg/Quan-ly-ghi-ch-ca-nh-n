import { useMemo, useState } from 'react';
import {
  ArrowDown,
  ArrowUp,
  Bell,
  Calendar,
  Check,
  Clock,
  Edit3,
  List,
  Plus,
  RotateCcw,
  Search,
  Trash2,
} from 'lucide-react';
import type {
  NoteCategory,
  NoteItem,
  SortOption,
  WeeklyGoal,
} from '../types/notes';
import {
  formatDateVN,
  getSpanDaysCount,
  getTodayISO,
  getWeekdayVN,
} from '../utils/storage';

interface NotesWorkspaceProps {
  notes: NoteItem[];
  goals: WeeklyGoal[];
  onToggleComplete: (id: string) => void;
  onDeleteNote: (id: string) => void;
  onMoveNote: (id: string, direction: 'up' | 'down') => void;
  onOpenCreate: () => void;
  onOpenEdit: (note: NoteItem) => void;
  onResetSeedData: () => void;
}

const CATEGORY_TABS: ('Tất cả' | NoteCategory)[] = [
  'Tất cả',
  'Học tập',
  'Lịch nhắc',
  'Dự án',
  'Ôn tập',
  'Cá nhân',
];

function priorityWeight(p: NoteItem['priority']): number {
  if (p === 'Cao') return 3;
  if (p === 'Trung bình') return 2;
  return 1;
}

export function NotesWorkspace({
  notes,
  goals,
  onToggleComplete,
  onDeleteNote,
  onMoveNote,
  onOpenCreate,
  onOpenEdit,
  onResetSeedData,
}: NotesWorkspaceProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'Tất cả' | NoteCategory>('Tất cả');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'completed'>('all');
  const [sortOption, setSortOption] = useState<SortOption>('custom');
  const [viewMode, setViewMode] = useState<'list' | 'timeline'>('list');
  const [selectedNoteId, setSelectedNoteId] = useState<string | null>(
    notes[0]?.id || null
  );
  const [confirmDeleteId, setConfirmDeleteId] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState(false);

  const todayISO = getTodayISO();

  const stats = useMemo(() => {
    const total = notes.length;
    const completed = notes.filter((n) => n.completed).length;
    const reminders = notes.filter((n) => n.reminderEnabled && !n.completed).length;
    const spanDays = getSpanDaysCount(notes);
    return { total, completed, reminders, spanDays };
  }, [notes]);

  const upcomingReminders = useMemo(() => {
    return [...notes]
      .filter((n) => !n.completed && n.reminderEnabled)
      .sort((a, b) =>
        `${a.scheduledDate} ${a.scheduledTime}`.localeCompare(
          `${b.scheduledDate} ${b.scheduledTime}`
        )
      )
      .slice(0, 3);
  }, [notes]);

  const filteredAndSortedNotes = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    const filtered = notes.filter((n) => {
      if (categoryFilter !== 'Tất cả' && n.category !== categoryFilter) {
        return false;
      }
      if (statusFilter === 'pending' && n.completed) return false;
      if (statusFilter === 'completed' && !n.completed) return false;
      if (q) {
        const matchesTitle = n.title.toLowerCase().includes(q);
        const matchesContent = n.content.toLowerCase().includes(q);
        if (!matchesTitle && !matchesContent) return false;
      }
      return true;
    });

    const sorted = [...filtered];
    switch (sortOption) {
      case 'custom':
        sorted.sort((a, b) => a.orderIndex - b.orderIndex);
        break;
      case 'schedule_asc':
        sorted.sort((a, b) =>
          `${a.scheduledDate} ${a.scheduledTime}`.localeCompare(
            `${b.scheduledDate} ${b.scheduledTime}`
          )
        );
        break;
      case 'schedule_desc':
        sorted.sort((a, b) =>
          `${b.scheduledDate} ${b.scheduledTime}`.localeCompare(
            `${a.scheduledDate} ${a.scheduledTime}`
          )
        );
        break;
      case 'priority_desc':
        sorted.sort((a, b) => {
          const diff = priorityWeight(b.priority) - priorityWeight(a.priority);
          if (diff !== 0) return diff;
          return a.orderIndex - b.orderIndex;
        });
        break;
      case 'title_asc':
        sorted.sort((a, b) => a.title.localeCompare(b.title, 'vi'));
        break;
      case 'status_pending_first':
        sorted.sort((a, b) => {
          if (a.completed !== b.completed) return a.completed ? 1 : -1;
          return `${a.scheduledDate} ${a.scheduledTime}`.localeCompare(
            `${b.scheduledDate} ${b.scheduledTime}`
          );
        });
        break;
      case 'updated_desc':
        sorted.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
        break;
    }
    return sorted;
  }, [notes, searchQuery, categoryFilter, statusFilter, sortOption]);

  const timelineGroups = useMemo(() => {
    const map = new Map<string, NoteItem[]>();
    const chrono = [...filteredAndSortedNotes].sort((a, b) =>
      `${a.scheduledDate} ${a.scheduledTime}`.localeCompare(
        `${b.scheduledDate} ${b.scheduledTime}`
      )
    );
    for (const item of chrono) {
      const key = item.scheduledDate || 'Chưa xếp ngày';
      const existing = map.get(key) || [];
      existing.push(item);
      map.set(key, existing);
    }
    return Array.from(map.entries());
  }, [filteredAndSortedNotes]);

  const selectedNote = useMemo(() => {
    return (
      notes.find((n) => n.id === selectedNoteId) ||
      filteredAndSortedNotes[0] ||
      null
    );
  }, [notes, selectedNoteId, filteredAndSortedNotes]);

  const linkedGoalTitle = useMemo(() => {
    if (!selectedNote?.goalId) return null;
    return goals.find((g) => g.id === selectedNote.goalId)?.title || null;
  }, [selectedNote, goals]);

  const isCustomReorderActive =
    sortOption === 'custom' &&
    categoryFilter === 'Tất cả' &&
    statusFilter === 'all' &&
    !searchQuery.trim();

  return (
    <div className="space-y-6">
      {/* Compact single-elevation KPI summary strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 rounded-lg border border-slate-200 bg-white divide-y lg:divide-y-0 lg:divide-x divide-slate-200">
        <div className="px-5 py-4">
          <p className="text-xs font-medium text-slate-500">Tổng số ghi chú</p>
          <p className="mt-1 font-display text-2xl font-bold text-slate-900 tabular-nums">
            {stats.total}
          </p>
        </div>
        <div className="px-5 py-4">
          <p className="text-xs font-medium text-slate-500">Đã hoàn thành</p>
          <p className="mt-1 font-display text-2xl font-bold text-emerald-700 tabular-nums">
            {stats.completed}
            <span className="text-sm font-normal text-slate-500">
              /{stats.total}
            </span>
          </p>
        </div>
        <div className="px-5 py-4">
          <p className="text-xs font-medium text-slate-500">Lịch nhắc đang chờ</p>
          <p className="mt-1 font-display text-2xl font-bold text-blue-700 tabular-nums">
            {stats.reminders}
          </p>
        </div>
        <div className="px-5 py-4">
          <p className="text-xs font-medium text-slate-500">Thời gian áp dụng</p>
          <p className="mt-1 font-display text-2xl font-bold text-slate-900 tabular-nums">
            {stats.spanDays}{' '}
            <span className="text-sm font-normal text-slate-500">ngày</span>
          </p>
        </div>
      </div>

      {/* Upcoming study reminder bar */}
      {upcomingReminders.length > 0 && (
        <div className="rounded-lg border border-slate-200 bg-white px-5 py-3.5">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900 shrink-0">
              <Bell className="h-4 w-4 text-amber-600" aria-hidden="true" />
              <span>Lịch nhắc học tập sắp tới:</span>
            </div>
            <div className="flex flex-wrap items-center gap-x-5 gap-y-2 text-xs text-slate-700">
              {upcomingReminders.map((rem) => (
                <button
                  key={rem.id}
                  type="button"
                  onClick={() => setSelectedNoteId(rem.id)}
                  className="inline-flex items-center gap-1.5 text-left hover:text-blue-700 transition-colors"
                >
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {formatDateVN(rem.scheduledDate).slice(0, 5)} {rem.scheduledTime}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="max-w-[220px] truncate">{rem.title}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Search, Filter, Sort, and View Controls */}
      <div className="rounded-lg border border-slate-200 bg-white p-4 space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400"
              aria-hidden="true"
            />
            <input
              type="search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Tìm kiếm theo tiêu đề hoặc nội dung ghi chú..."
              className="w-full rounded-md border border-slate-300 bg-white pl-9 pr-3 py-2 text-sm text-slate-900 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <select
              value={statusFilter}
              onChange={(e) =>
                setStatusFilter(e.target.value as 'all' | 'pending' | 'completed')
              }
              aria-label="Lọc theo trạng thái"
              className="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-blue-600 focus:outline-none"
            >
              <option value="all">Tất cả trạng thái</option>
              <option value="pending">Chưa hoàn thành</option>
              <option value="completed">Đã hoàn thành</option>
            </select>

            <select
              value={sortOption}
              onChange={(e) => setSortOption(e.target.value as SortOption)}
              aria-label="Sắp xếp thứ tự ghi chú"
              className="rounded-md border border-slate-300 bg-white px-3 py-2 text-xs font-medium text-slate-700 focus:border-blue-600 focus:outline-none"
            >
              <option value="custom">Sắp xếp: Thứ tự tùy chỉnh (↑/↓)</option>
              <option value="schedule_asc">Sắp xếp: Lịch nhắc gần nhất</option>
              <option value="schedule_desc">Sắp xếp: Lịch nhắc xa nhất</option>
              <option value="priority_desc">Sắp xếp: Ưu tiên cao trước</option>
              <option value="status_pending_first">Sắp xếp: Chưa xong trước</option>
              <option value="title_asc">Sắp xếp: Tiêu đề (A → Z)</option>
              <option value="updated_desc">Sắp xếp: Mới cập nhật</option>
            </select>

            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-md">
              <button
                type="button"
                onClick={() => setViewMode('list')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                  viewMode === 'list'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <List className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Danh sách</span>
              </button>
              <button
                type="button"
                onClick={() => setViewMode('timeline')}
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded text-xs font-medium whitespace-nowrap transition-colors ${
                  viewMode === 'timeline'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Calendar className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Lịch 5+ ngày</span>
              </button>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100">
          <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-md">
            {CATEGORY_TABS.map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                className={`px-3 py-1.5 text-xs font-medium rounded transition-colors whitespace-nowrap shrink-0 ${
                  categoryFilter === cat
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            {!confirmReset ? (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="inline-flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 whitespace-nowrap"
              >
                <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Khôi phục 12 ghi chú mẫu</span>
              </button>
            ) : (
              <div className="flex items-center gap-2 text-xs">
                <span className="text-slate-600">Khôi phục dữ liệu mẫu?</span>
                <button
                  type="button"
                  onClick={() => {
                    onResetSeedData();
                    setConfirmReset(false);
                  }}
                  className="px-2.5 py-1 rounded bg-slate-900 text-white font-medium hover:bg-slate-800 whitespace-nowrap"
                >
                  Xác nhận
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-2 py-1 text-slate-600 hover:text-slate-900 whitespace-nowrap"
                >
                  Hủy
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Main Content Area: List / Timeline + Detail Inspector */}
      {viewMode === 'list' ? (
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
          {/* Note List */}
          <div className="xl:col-span-7 rounded-lg border border-slate-200 bg-white overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3.5 border-b border-slate-200 bg-slate-50/70">
              <span className="text-sm font-semibold text-slate-900">
                Danh sách ghi chú ({filteredAndSortedNotes.length})
              </span>
              {sortOption === 'custom' && !isCustomReorderActive && (
                <span className="text-xs text-slate-500">
                  Xóa bộ lọc để đổi thứ tự ↑/↓
                </span>
              )}
            </div>

            {filteredAndSortedNotes.length === 0 ? (
              <div className="p-10 text-center space-y-3">
                <p className="text-sm font-medium text-slate-800">
                  Không tìm thấy ghi chú phù hợp với bộ lọc hiện tại.
                </p>
                <p className="text-xs text-slate-500">
                  Hãy thử thay đổi từ khóa tìm kiếm hoặc tạo một ghi chú mới.
                </p>
                <button
                  type="button"
                  onClick={onOpenCreate}
                  className="inline-flex items-center gap-1.5 rounded-md bg-blue-600 px-4 py-2 text-xs font-medium text-white hover:bg-blue-700"
                >
                  <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                  <span>Thêm ghi chú đầu tiên</span>
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-200">
                {filteredAndSortedNotes.map((note, index) => {
                  const isSelected = selectedNote?.id === note.id;
                  const priorityColor =
                    note.priority === 'Cao'
                      ? 'text-red-700 font-medium'
                      : note.priority === 'Trung bình'
                        ? 'text-amber-700 font-medium'
                        : 'text-slate-500';

                  return (
                    <div
                      key={note.id}
                      onClick={() => setSelectedNoteId(note.id)}
                      className={`group flex items-start justify-between gap-3 px-5 py-3.5 cursor-pointer transition-colors ${
                        isSelected ? 'bg-blue-50/50' : 'hover:bg-slate-50'
                      }`}
                    >
                      <div className="flex items-start gap-3 min-w-0 flex-1">
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            onToggleComplete(note.id);
                          }}
                          aria-label={
                            note.completed
                              ? `Đánh dấu chưa xong: ${note.title}`
                              : `Đánh dấu hoàn thành: ${note.title}`
                          }
                          className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors ${
                            note.completed
                              ? 'border-emerald-600 bg-emerald-600 text-white'
                              : 'border-slate-300 bg-white hover:border-blue-600'
                          }`}
                        >
                          {note.completed && <Check className="h-3.5 w-3.5" />}
                        </button>

                        <div className="min-w-0 flex-1">
                          <h3
                            className={`text-sm font-semibold leading-snug ${
                              note.completed
                                ? 'line-through text-slate-400'
                                : 'text-slate-900'
                            }`}
                          >
                            {note.title}
                          </h3>

                          <p className="mt-1 text-xs text-slate-600 line-clamp-1">
                            {note.content}
                          </p>

                          {/* Zero-pill clean inline metadata */}
                          <div className="mt-1.5 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 tabular-nums">
                            <span className="font-medium text-slate-700">
                              {note.category}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>
                              {getWeekdayVN(note.scheduledDate)}{' '}
                              {formatDateVN(note.scheduledDate)}
                              {note.scheduledDate === todayISO ? ' (Hôm nay)' : ''}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono">{note.scheduledTime}</span>
                            <span aria-hidden="true">·</span>
                            <span>{note.durationMinutes} phút</span>
                            <span aria-hidden="true">·</span>
                            <span className={priorityColor}>
                              Ưu tiên {note.priority}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div
                        className="flex items-center gap-1 shrink-0"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {isCustomReorderActive && (
                          <>
                            <button
                              type="button"
                              disabled={index === 0}
                              onClick={() => onMoveNote(note.id, 'up')}
                              aria-label={`Di chuyển lên: ${note.title}`}
                              className="rounded p-1.5 text-slate-400 hover:bg-slate-200/70 hover:text-slate-900 disabled:opacity-30 disabled:pointer-events-none"
                            >
                              <ArrowUp className="h-3.5 w-3.5" />
                            </button>
                            <button
                              type="button"
                              disabled={index === filteredAndSortedNotes.length - 1}
                              onClick={() => onMoveNote(note.id, 'down')}
                              aria-label={`Di chuyển xuống: ${note.title}`}
                              className="rounded p-1.5 text-slate-400 hover:bg-slate-200/70 hover:text-slate-900 disabled:opacity-30 disabled:pointer-events-none"
                            >
                              <ArrowDown className="h-3.5 w-3.5" />
                            </button>
                          </>
                        )}

                        <button
                          type="button"
                          onClick={() => onOpenEdit(note)}
                          aria-label={`Sửa ghi chú: ${note.title}`}
                          className="rounded p-1.5 text-slate-400 hover:bg-slate-200/70 hover:text-blue-700"
                        >
                          <Edit3 className="h-3.5 w-3.5" />
                        </button>

                        {confirmDeleteId === note.id ? (
                          <div className="flex items-center gap-1 ml-1">
                            <button
                              type="button"
                              onClick={() => {
                                onDeleteNote(note.id);
                                setConfirmDeleteId(null);
                              }}
                              className="rounded bg-red-600 px-2 py-1 text-xs font-medium text-white hover:bg-red-700 whitespace-nowrap"
                            >
                              Xóa
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmDeleteId(null)}
                              className="rounded px-1.5 py-1 text-xs text-slate-600 hover:text-slate-900 whitespace-nowrap"
                            >
                              Hủy
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmDeleteId(note.id)}
                            aria-label={`Xóa ghi chú: ${note.title}`}
                            className="rounded p-1.5 text-slate-400 hover:bg-red-50 hover:text-red-600"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Right Detail Inspector */}
          <div className="xl:col-span-5 rounded-lg border border-slate-200 bg-white p-6">
            {selectedNote ? (
              <div className="space-y-5">
                <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
                  <div className="space-y-1.5 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500">
                      <span className="font-medium text-slate-800">
                        {selectedNote.category}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {selectedNote.completed ? 'Đã hoàn thành' : 'Đang thực hiện'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>Ưu tiên {selectedNote.priority}</span>
                    </div>
                    <h2 className="font-display text-xl font-bold text-slate-900 leading-snug">
                      {selectedNote.title}
                    </h2>
                  </div>
                </div>

                <div className="space-y-2">
                  <h3 className="text-xs font-semibold text-slate-500">
                    Nội dung ghi chú
                  </h3>
                  <p className="text-sm leading-relaxed text-slate-800 whitespace-pre-line">
                    {selectedNote.content}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-3 border-t border-slate-200 text-xs">
                  <div>
                    <span className="text-slate-500 block">Ngày áp dụng</span>
                    <span className="mt-1 inline-block font-mono font-medium text-slate-900 tabular-nums">
                      {getWeekdayVN(selectedNote.scheduledDate)},{' '}
                      {formatDateVN(selectedNote.scheduledDate)}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Giờ nhắc & Thời lượng</span>
                    <span className="mt-1 inline-block font-mono font-medium text-slate-900 tabular-nums">
                      {selectedNote.scheduledTime} ({selectedNote.durationMinutes} phút)
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Trạng thái nhắc nhở</span>
                    <span className="mt-1 inline-block font-medium text-slate-900">
                      {selectedNote.reminderEnabled ? 'Đang bật lịch nhắc' : 'Không nhắc'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Mục tiêu tuần liên kết</span>
                    <span className="mt-1 inline-block font-medium text-slate-900">
                      {linkedGoalTitle || 'Chưa gắn mục tiêu'}
                    </span>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-3 pt-4 border-t border-slate-200">
                  <button
                    type="button"
                    onClick={() => onToggleComplete(selectedNote.id)}
                    className={`px-4 py-2 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                      selectedNote.completed
                        ? 'border border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
                        : 'bg-emerald-600 text-white hover:bg-emerald-700'
                    }`}
                  >
                    {selectedNote.completed
                      ? 'Đánh dấu chưa xong'
                      : 'Hoàn thành ghi chú'}
                  </button>
                  <button
                    type="button"
                    onClick={() => onOpenEdit(selectedNote)}
                    className="px-4 py-2 rounded-md border border-slate-300 bg-white text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap"
                  >
                    Chỉnh sửa nội dung
                  </button>
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-sm text-slate-500">
                Chọn một ghi chú trong danh sách để xem nội dung chi tiết.
              </div>
            )}
          </div>
        </div>
      ) : (
        /* 5+ Day Timeline View */
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-600">
            <span>
              Hiển thị theo dòng thời gian ({timelineGroups.length} ngày áp dụng)
            </span>
          </div>

          {timelineGroups.length === 0 ? (
            <div className="rounded-lg border border-slate-200 bg-white p-10 text-center text-sm text-slate-500">
              Không có ghi chú nào phù hợp để hiển thị theo lịch ngày.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {timelineGroups.map(([dateKey, dayNotes]) => {
                const totalMins = dayNotes.reduce(
                  (sum, n) => sum + n.durationMinutes,
                  0
                );
                const doneCount = dayNotes.filter((n) => n.completed).length;
                const isToday = dateKey === todayISO;

                return (
                  <div
                    key={dateKey}
                    className="rounded-lg border border-slate-200 bg-white overflow-hidden flex flex-col"
                  >
                    <div
                      className={`px-4 py-3 border-b border-slate-200 flex items-center justify-between ${
                        isToday ? 'bg-blue-50/70' : 'bg-slate-50/70'
                      }`}
                    >
                      <div>
                        <p className="text-sm font-semibold text-slate-900">
                          {getWeekdayVN(dateKey)} · {formatDateVN(dateKey)}
                          {isToday ? ' (Hôm nay)' : ''}
                        </p>
                        <p className="text-xs text-slate-500 tabular-nums mt-0.5">
                          {doneCount}/{dayNotes.length} hoàn thành · {totalMins} phút
                        </p>
                      </div>
                    </div>

                    <div className="divide-y divide-slate-200 flex-1">
                      {dayNotes.map((item) => (
                        <div
                          key={item.id}
                          onClick={() => {
                            setSelectedNoteId(item.id);
                            onOpenEdit(item);
                          }}
                          className="p-4 hover:bg-slate-50 cursor-pointer space-y-1.5 transition-colors"
                        >
                          <div className="flex items-center justify-between gap-2 text-xs text-slate-500 tabular-nums">
                            <span className="inline-flex items-center gap-1 font-mono font-medium text-slate-800">
                              <Clock className="h-3 w-3 text-slate-400" aria-hidden="true" />
                              {item.scheduledTime} ({item.durationMinutes}p)
                            </span>
                            <span>
                              {item.completed ? 'Hoàn thành' : `Ưu tiên ${item.priority}`}
                            </span>
                          </div>
                          <p
                            className={`text-sm font-semibold ${
                              item.completed
                                ? 'line-through text-slate-400'
                                : 'text-slate-900'
                            }`}
                          >
                            {item.title}
                          </p>
                          <p className="text-xs text-slate-600 line-clamp-2">
                            {item.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
